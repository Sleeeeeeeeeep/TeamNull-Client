package cf.warriorcrystal.other.xulu;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.world.World;

public class Wrapper {

    public static Minecraft getMinecraft() {
        return Minecraft.func_71410_x();
    }
    public static EntityPlayerSP getPlayer() {
        return getMinecraft().field_71439_g;
    }
    public static World getWorld() {
        return getMinecraft().field_71441_e;
    }
	
}
