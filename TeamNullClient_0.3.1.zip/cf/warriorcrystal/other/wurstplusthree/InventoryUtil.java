package cf.warriorcrystal.other.wurstplusthree;

import net.minecraft.block.Block;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.Slot;
import net.minecraft.item.*;
import net.minecraft.network.play.client.CPacketHeldItemChange;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InventoryUtil implements Globals {

    public static boolean isNull(ItemStack stack) {
        return stack == null || stack.func_77973_b() instanceof ItemAir;
    }

    public static void switchToHotbarSlot(int slot, boolean silent) {
        if (InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c == slot || slot < 0) {
            return;
        }
        if (silent) {
            InventoryUtil.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(slot));
            InventoryUtil.mc.field_71442_b.func_78765_e();
        } else {
            InventoryUtil.mc.field_71439_g.field_71174_a.func_147297_a(new CPacketHeldItemChange(slot));
            InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c = slot;
            InventoryUtil.mc.field_71442_b.func_78765_e();
        }
    }

    public static boolean isBlock(Item item, Class c) {
        if (item instanceof ItemBlock) {
            Block block = ((ItemBlock) item).func_179223_d();
            return c.isInstance(block);
        }
        return false;
    }

    public static Map<Integer, ItemStack> getInventoryAndHotbarSlots() {
        return InventoryUtil.getInventorySlots(9, 44);
    }

    private static Map<Integer, ItemStack> getInventorySlots(int currentI, int last) {
        HashMap<Integer, ItemStack> fullInventorySlots = new HashMap<Integer, ItemStack>();
        for (int current = currentI; current <= last; ++current) {
            fullInventorySlots.put(current, InventoryUtil.mc.field_71439_g.field_71069_bz.func_75138_a().get(current));
        }
        return fullInventorySlots;
    }

    public static List<Integer> findEmptySlots(boolean withXCarry) {
        ArrayList<Integer> outPut = new ArrayList<Integer>();
        for (Map.Entry<Integer, ItemStack> entry : InventoryUtil.getInventoryAndHotbarSlots().entrySet()) {
            if (!entry.getValue().field_190928_g && entry.getValue().func_77973_b() != Items.field_190931_a) continue;
            outPut.add(entry.getKey());
        }
        if (withXCarry) {
            for (int i = 1; i < 5; ++i) {
                Slot craftingSlot = InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
                ItemStack craftingStack = craftingSlot.func_75211_c();
                if (!craftingStack.func_190926_b() && craftingStack.func_77973_b() != Items.field_190931_a) continue;
                outPut.add(i);
            }
        }
        return outPut;
    }

    public static int findArmorSlot(EntityEquipmentSlot type, boolean binding) {
        int slot = -1;
        float damage = 0.0f;
        for (int i = 9; i < 45; ++i) {
            boolean cursed;
            ItemArmor armor;
            ItemStack s = mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
            if (s.func_77973_b() == Items.field_190931_a || !(s.func_77973_b() instanceof ItemArmor) || (armor = (ItemArmor) s.func_77973_b()).func_185083_B_() != type)
                continue;
            float currentDamage = armor.field_77879_b + EnchantmentHelper.func_77506_a(Enchantments.field_180310_c, s);
            cursed = binding && EnchantmentHelper.func_190938_b(s);
            if (!(currentDamage > damage) || cursed) continue;
            damage = currentDamage;
            slot = i;
        }
        return slot;
    }

    public static boolean holdingItem(Class c) {
    	
    	if (isInstanceOf(mc.field_71439_g.func_184614_ca(), c) || isInstanceOf(mc.field_71439_g.func_184592_cb(), c)) {
    		return true;
    	} return false;
    }

    public static boolean isInstanceOf(ItemStack stack, Class c) {
        if (stack == null) {
            return false;
        }
        Item item = stack.func_77973_b();
        if (c.isInstance(item)) {
            return true;
        }
        if (item instanceof ItemBlock) {
            Block block = Block.func_149634_a(item);
            return c.isInstance(block);
        }
        return false;
    }

    public static int findArmorSlot(EntityEquipmentSlot type, boolean binding, boolean withXCarry) {
        int slot = InventoryUtil.findArmorSlot(type, binding);
        if (slot == -1 && withXCarry) {
            float damage = 0.0f;
            for (int i = 1; i < 5; ++i) {
                boolean cursed;
                ItemArmor armor;
                Slot craftingSlot = InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
                ItemStack craftingStack = craftingSlot.func_75211_c();
                if (craftingStack.func_77973_b() == Items.field_190931_a || !(craftingStack.func_77973_b() instanceof ItemArmor) || (armor = (ItemArmor) craftingStack.func_77973_b()).func_185083_B_() != type)
                    continue;
                float currentDamage = armor.field_77879_b + EnchantmentHelper.func_77506_a(Enchantments.field_180310_c, craftingStack);
                cursed = binding && EnchantmentHelper.func_190938_b(craftingStack);
                if (!(currentDamage > damage) || cursed) continue;
                damage = currentDamage;
                slot = i;
            }
        }
        return slot;
    }

    public static void switchToHotbarSlot(Class c, boolean silent) {
        int slot = InventoryUtil.findHotbarBlock(c);
        if (slot > -1) {
            InventoryUtil.switchToHotbarSlot(slot, silent);
        }
    }

    public static int findHotbarBlock(Class c) {
        for (int i = 0; i < 9; ++i) {
            ItemStack stack = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack == ItemStack.field_190927_a) continue;
            if (c.isInstance(stack.func_77973_b())) {
                return i;
            }
            if (!(stack.func_77973_b() instanceof ItemBlock) || !c.isInstance(((ItemBlock) stack.func_77973_b()).func_179223_d()))
                continue;
            return i;
        }
        return -1;
    }

    public static class Task {
        private final int slot;
        private final boolean update;
        private final boolean quickClick;

        public Task() {
            this.update = true;
            this.slot = -1;
            this.quickClick = false;
        }

        public Task(int slot) {
            this.slot = slot;
            this.quickClick = false;
            this.update = false;
        }

        public Task(int slot, boolean quickClick) {
            this.slot = slot;
            this.quickClick = quickClick;
            this.update = false;
        }

        public void run() {
            if (this.update) {
                mc.field_71442_b.func_78765_e();
            }
            if (this.slot != -1) {
                mc.field_71442_b.func_187098_a(0, this.slot, 0, this.quickClick ? ClickType.QUICK_MOVE : ClickType.PICKUP, mc.field_71439_g);
            }
        }

        public boolean isSwitching() {
            return !this.update;
        }
    }

}
