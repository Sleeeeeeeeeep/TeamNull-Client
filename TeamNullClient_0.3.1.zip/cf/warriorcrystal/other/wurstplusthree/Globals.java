package cf.warriorcrystal.other.wurstplusthree;

import net.minecraft.client.Minecraft;

import java.util.Random;

public interface Globals {
    Minecraft mc = Minecraft.func_71410_x();
    Random random = new Random();
    char SECTIONSIGN = '\u00A7';

    default public boolean nullCheck(){
        return mc.field_71439_g == null || mc.field_71441_e == null;
    }

}