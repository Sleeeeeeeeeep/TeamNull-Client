package me.travis.wurstplus.wurstplustwo.guiscreen.hud;

import me.travis.wurstplus.Wurstplus;
import me.travis.wurstplus.wurstplustwo.guiscreen.render.pinnables.WurstplusPinnable;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;


public class WurstplusTotemCount extends WurstplusPinnable {
	int totems = 0;

	public WurstplusTotemCount() {
		super("Totem Count", "TotemCount", 1, 0, 0);
	}

	@Override
	public void render() {
		int nl_r = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorR").get_value(1);
		int nl_g = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorG").get_value(1);
		int nl_b = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorB").get_value(1);
		int nl_a = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorA").get_value(1);

		if (mc.field_71439_g != null) {
			if (is_on_gui()) {
				create_rect(0, 0, this.get_width(), this.get_height(), 0, 0, 0, 50);
			}

			GlStateManager.func_179094_E();
			RenderHelper.func_74520_c();

			totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(stack -> stack.func_77973_b() == Items.field_190929_cY).mapToInt(ItemStack::func_190916_E).sum();

			int off = 0;

			for (int i = 0; i < 45; i++) {
				ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
				ItemStack off_h = mc.field_71439_g.func_184592_cb();

				if (off_h.func_77973_b() == Items.field_190929_cY) {
					off = off_h.func_77976_d();
				} else {
					off = 0;
				}

				if (stack.func_77973_b() == Items.field_190929_cY) {
					mc.func_175599_af().func_180450_b(stack, this.get_x(), this.get_y());
					
					create_line(Integer.toString(totems + off), 16 + 2, 16 - get(Integer.toString(totems + off), "height"), nl_r, nl_g, nl_b, nl_a);
				}
			}

			mc.func_175599_af().field_77023_b = 0.0f;

			RenderHelper.func_74518_a();		
			
			GlStateManager.func_179121_F();

			this.set_width(16 + get(Integer.toString(totems + off), "width") + 2);
			this.set_height(16);
		}
	}
}