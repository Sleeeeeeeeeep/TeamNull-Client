package me.travis.wurstplus.wurstplustwo.util;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class WurstplusOnlineFriends {

    public static List<Entity> entities = new ArrayList<Entity>();

    static public List<Entity> getFriends() {
        entities.clear();
        entities.addAll(Minecraft.func_71410_x().field_71441_e.field_73010_i.stream().filter(entityPlayer -> WurstplusFriendUtil.isFriend(entityPlayer.func_70005_c_())).collect(Collectors.toList()));
     
        return entities;
    }
       
}