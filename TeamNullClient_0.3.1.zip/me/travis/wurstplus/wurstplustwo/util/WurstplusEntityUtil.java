package me.travis.wurstplus.wurstplustwo.util;


import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class WurstplusEntityUtil {

    public static final Minecraft mc = Minecraft.func_71410_x();

    public static void attackEntity(final Entity entity, final boolean packet, final WurstplusSetting setting) {
        if (packet) {
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketUseEntity(entity));
        }
        else {
            mc.field_71442_b.func_78764_a(mc.field_71439_g, entity);
        }
        if (setting.in("Mainhand") || setting.in("Both")) {
            mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        }
        if (setting.in("Offhand") || setting.in("Both")) {
            mc.field_71439_g.func_184609_a(EnumHand.OFF_HAND);
        }
    }

    public static boolean isLiving(Entity e)
    {
        return e instanceof EntityLivingBase;
    }

    public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z)
    {
        return new Vec3d((entity.field_70165_t - entity.field_70142_S) * x, 0 * y,
                (entity.field_70161_v - entity.field_70136_U) * z);
    }

    public static Vec3d getInterpolatedAmount(Entity entity, double ticks)
    {
        return getInterpolatedAmount(entity, ticks, ticks, ticks);
    }

    public static Vec3d getInterpolatedPos(Entity entity, float ticks)
    {
        return new Vec3d(entity.field_70142_S, entity.field_70137_T, entity.field_70136_U)
                .func_178787_e(getInterpolatedAmount(entity, ticks));
    }

    public static Vec3d getInterpolatedRenderPos(Entity entity, float ticks)
    {
        return getInterpolatedPos(entity, ticks).func_178786_a(mc.func_175598_ae().field_78725_b,
                mc.func_175598_ae().field_78726_c,
                mc.func_175598_ae().field_78723_d);
    }

    public static BlockPos is_cityable(final EntityPlayer player, final boolean end_crystal) {

        BlockPos pos = new BlockPos(player.field_70165_t, player.field_70163_u, player.field_70161_v);

        if (mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150343_Z) {
            if (end_crystal) {
                return pos.func_177978_c();
            }
            else if (mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177978_c()).func_177230_c() == Blocks.field_150350_a) {
                return pos.func_177978_c();
            }
        }
        if (mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150343_Z) {
            if (end_crystal) {
                return pos.func_177974_f();
            }
            else if (mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177974_f()).func_177230_c() == Blocks.field_150350_a) {
                return pos.func_177974_f();
            }
        }
        if (mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150343_Z) {
            if (end_crystal) {
                return pos.func_177968_d();
            }
            else if (mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177968_d()).func_177230_c() == Blocks.field_150350_a) {
                return pos.func_177968_d();
            }

        }
        if (mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150343_Z) {
            if (end_crystal) {
                return pos.func_177976_e();
            }
            else if (mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177976_e()).func_177230_c() == Blocks.field_150350_a) {
                return pos.func_177976_e();
            }
        }

        return null;

    }

}