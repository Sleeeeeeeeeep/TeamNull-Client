package me.travis.wurstplus.wurstplustwo.hacks.misc;

import com.mojang.authlib.GameProfile;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.client.entity.EntityOtherPlayerMP;

import java.util.UUID;

public class WurstplusFakePlayer extends WurstplusHack {
    
    public WurstplusFakePlayer() {
        super(WurstplusCategory.WURSTPLUS_MISC);

		this.name        = "Fake Player";
		this.tag         = "FakePlayer";
		this.description = "hahahaaha what a noob its in beta ahahahahaha";
    }

    private EntityOtherPlayerMP fake_player;

    @Override
    protected void enable() {
        
        fake_player = new EntityOtherPlayerMP(mc.field_71441_e, new GameProfile(UUID.fromString("a07208c2-01e5-4eac-a3cf-a5f5ef2a4700"), "Pou"));
        fake_player.func_82149_j(mc.field_71439_g);
        fake_player.field_70759_as = mc.field_71439_g.field_70759_as;
        mc.field_71441_e.func_73027_a(-100, fake_player);

    }

    @Override
    protected void disable() {
        try {
            mc.field_71441_e.func_72900_e(fake_player);
        } catch (Exception ignored) {}
    }

}