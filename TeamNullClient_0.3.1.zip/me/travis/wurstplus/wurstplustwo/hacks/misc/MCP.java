package me.travis.wurstplus.wurstplustwo.hacks.misc;

import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventPlayerTravel;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;

import me.zero.alpine.fork.listener.EventHandler;
import me.zero.alpine.fork.listener.Listener;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import org.lwjgl.input.Mouse;

public class MCP extends WurstplusHack {
	   private boolean clicked;
	public MCP() {
		super(WurstplusCategory.WURSTPLUS_MISC);
		this.name = "MCP";
		this.tag = "MCP";
		this.description = "throws a pearl when middleclick";
	}
    @EventHandler
    private final Listener<WurstplusEventPlayerTravel> listener = new Listener<>(p_Event -> {
        if(mc.field_71462_r == null && Mouse.isButtonDown(2)) {
            if(!this.clicked) {
                    final int pearlSLot = findPearlInHotbar();
                    if(pearlSLot  != -1) {
                        final int oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
                        mc.field_71439_g.field_71071_by.field_70461_c = pearlSLot;
                        mc.field_71442_b.func_187101_a(mc.field_71439_g, mc.field_71441_e, EnumHand.MAIN_HAND);
                        mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
                    }
                }
                this.clicked = true;
            } else {
                this.clicked = false;
            }
        });

    private boolean isItemStackPearl(final ItemStack itemStack) {
        return itemStack.func_77973_b() instanceof ItemEnderPearl;
    }


    private int findPearlInHotbar() {
        for (int index = 0; InventoryPlayer.func_184435_e(index); index++) {
            if (isItemStackPearl(mc.field_71439_g.field_71071_by.func_70301_a(index))) return index;
        }
        return -1;
    }
}
