package me.travis.wurstplus.wurstplustwo.hacks.misc;


import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusBlockInteractHelper;
import me.travis.wurstplus.wurstplustwo.util.WurstplusMessageUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class WurstplusAutoNomadHut extends WurstplusHack {
    
    public WurstplusAutoNomadHut() {

        super(WurstplusCategory.WURSTPLUS_MISC);

        this.name = "Auto NomadHut";
        this.tag = "AutoNomadHut";
        this.description = "i fucking hate fit";
    }

    WurstplusSetting rotate         = create("Rotate",           "NomadSmoth",       true);
	WurstplusSetting triggerable    = create("Toggle",			 "NomadToggle", 		true);
	WurstplusSetting tick_for_place = create("Blocks per tick",	 "NomadTickToPlace", 2, 1, 8);

    Vec3d[] targets = new Vec3d[] { new Vec3d(0.0, 0.0, 0.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 1.0), new Vec3d(1.0, 0.0, -1.0), new Vec3d(-1.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, -1.0), new Vec3d(2.0, 0.0, 0.0), new Vec3d(2.0, 0.0, 1.0), new Vec3d(2.0, 0.0, -1.0), new Vec3d(-2.0, 0.0, 0.0), new Vec3d(-2.0, 0.0, 1.0), new Vec3d(-2.0, 0.0, -1.0), new Vec3d(0.0, 0.0, 2.0), new Vec3d(1.0, 0.0, 2.0), new Vec3d(-1.0, 0.0, 2.0), new Vec3d(0.0, 0.0, -2.0), new Vec3d(-1.0, 0.0, -2.0), new Vec3d(1.0, 0.0, -2.0), new Vec3d(2.0, 1.0, -1.0), new Vec3d(2.0, 1.0, 1.0), new Vec3d(-2.0, 1.0, 0.0), new Vec3d(-2.0, 1.0, 1.0), new Vec3d(-2.0, 1.0, -1.0), new Vec3d(0.0, 1.0, 2.0), new Vec3d(1.0, 1.0, 2.0), new Vec3d(-1.0, 1.0, 2.0), new Vec3d(0.0, 1.0, -2.0), new Vec3d(1.0, 1.0, -2.0), new Vec3d(-1.0, 1.0, -2.0), new Vec3d(2.0, 2.0, -1.0), new Vec3d(2.0, 2.0, 1.0), new Vec3d(-2.0, 2.0, 1.0), new Vec3d(-2.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 2.0), new Vec3d(-1.0, 2.0, 2.0), new Vec3d(1.0, 2.0, -2.0), new Vec3d(-1.0, 2.0, -2.0), new Vec3d(2.0, 3.0, 0.0), new Vec3d(2.0, 3.0, -1.0), new Vec3d(2.0, 3.0, 1.0), new Vec3d(-2.0, 3.0, 0.0), new Vec3d(-2.0, 3.0, 1.0), new Vec3d(-2.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 2.0), new Vec3d(1.0, 3.0, 2.0), new Vec3d(-1.0, 3.0, 2.0), new Vec3d(0.0, 3.0, -2.0), new Vec3d(1.0, 3.0, -2.0), new Vec3d(-1.0, 3.0, -2.0), new Vec3d(0.0, 4.0, 0.0), new Vec3d(1.0, 4.0, 0.0), new Vec3d(-1.0, 4.0, 0.0), new Vec3d(0.0, 4.0, 1.0), new Vec3d(0.0, 4.0, -1.0), new Vec3d(1.0, 4.0, 1.0), new Vec3d(-1.0, 4.0, 1.0), new Vec3d(-1.0, 4.0, -1.0), new Vec3d(1.0, 4.0, -1.0), new Vec3d(2.0, 4.0, 0.0), new Vec3d(2.0, 4.0, 1.0), new Vec3d(2.0, 4.0, -1.0) };

    int new_slot    	= 0;
	int old_slot    	= 0;
	int y_level 		= 0;
	int tick_runs  		= 0;
	int blocks_placed 	= 0;
    int offset_step 	= 0;
    
    boolean sneak = false;

    @Override
	public void enable() {

		if (mc.field_71439_g != null) {

			old_slot = mc.field_71439_g.field_71071_by.field_70461_c;
			new_slot = find_in_hotbar();

			if (new_slot == -1) {
				WurstplusMessageUtil.send_client_error_message("cannot find obi in hotbar");
				set_active(false);
			}

			y_level = (int) Math.round(mc.field_71439_g.field_70163_u);

		}

	}

	@Override
	public void disable() {

		if (mc.field_71439_g != null) {

			if (new_slot != old_slot && old_slot != - 1) {
				mc.field_71439_g.field_71071_by.field_70461_c = old_slot;
			}

			if (sneak) {
				mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));

				sneak = false;
			}

			old_slot = - 1;
			new_slot = - 1;
		}

	}

	@Override
	public void update() {

		if (mc.field_71439_g != null) {

			blocks_placed = 0;

			while (blocks_placed < this.tick_for_place.get_value(1)) {

				if (this.offset_step >= this.targets.length) {
					this.offset_step = 0;
					break;
				}

				BlockPos offsetPos = new BlockPos(this.targets[this.offset_step]);
				BlockPos targetPos = new BlockPos(mc.field_71439_g.func_174791_d()).func_177982_a(offsetPos.func_177958_n(), offsetPos.func_177956_o(), offsetPos.func_177952_p()).func_177977_b();

				boolean try_to_place = true;

				if (!mc.field_71441_e.func_180495_p(targetPos).func_185904_a().func_76222_j()) {
					try_to_place = false;
				}

				for (Entity entity : mc.field_71441_e.func_72839_b(null, new AxisAlignedBB(targetPos))) {
					if (entity instanceof EntityItem || entity instanceof EntityXPOrb) continue;
					try_to_place = false;
					break;
				}

				if (try_to_place && this.place_blocks(targetPos)) {
					++blocks_placed;
				}

				++offset_step;

			}

			if (blocks_placed > 0 && this.new_slot != this.old_slot) {
				mc.field_71439_g.field_71071_by.field_70461_c = this.old_slot;
			}

			++this.tick_runs;

		}
	}

	private boolean place_blocks(BlockPos pos) {

        if (!mc.field_71441_e.func_180495_p(pos).func_185904_a().func_76222_j()) {
            return false;
		}
		
        if (!WurstplusBlockInteractHelper.checkForNeighbours(pos)) {
            return false;
		}
		
        for (EnumFacing side : EnumFacing.values()) {

            Block neighborPos;
			BlockPos neighbor = pos.func_177972_a(side);
			
			EnumFacing side2 = side.func_176734_d();
			
			if (!WurstplusBlockInteractHelper.canBeClicked(neighbor)) continue;
			
			mc.field_71439_g.field_71071_by.field_70461_c = new_slot;

            if (WurstplusBlockInteractHelper.blackList.contains((Object)(neighborPos = mc.field_71441_e.func_180495_p(neighbor).func_177230_c()))) {
                mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                this.sneak = true;
			}
			
			Vec3d hitVec = new Vec3d((Vec3i)neighbor).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(side2.func_176730_m()).func_186678_a(0.5));
			
            if (this.rotate.get_value(true)) {
                WurstplusBlockInteractHelper.faceVectorPacketInstant(hitVec);
			}
			
            mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
			mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
			
            return true;
		}
		
		return false;
		
    }

	private int find_in_hotbar() {

        for (int i = 0; i < 9; ++i) {

            final ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);

            if (stack != ItemStack.field_190927_a && stack.func_77973_b() instanceof ItemBlock) {

                final Block block = ((ItemBlock) stack.func_77973_b()).func_179223_d();

                if (block instanceof BlockEnderChest)
                    return i;
                
                else if (block instanceof BlockObsidian)
                    return i;
                
            }
        }
        return -1;
    }


}