package me.travis.wurstplus.wurstplustwo.hacks.misc;

import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;

import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class MapEffectSpoofer extends WurstplusHack {
    public MapEffectSpoofer() {
        super(WurstplusCategory.WURSTPLUS_MISC);
        this.name = "Effect Spoofer";
        this.tag = "EffectSpoofer";
        this.description = "";
    }
    // 100% no paste de AnasheClient+
    WurstplusSetting speed = create("Speed", "CSPSpeed", 1, 0, 5);
    WurstplusSetting strong = create("Strenght", "Multiplier", 1, 0, 3);
    //     nullname y usuni be like:^
    WurstplusSetting haste = create("Haste", "HSpeed", 1, 0, 3);


    @Override
    public void update() {

        // espid (speed)
        if(speed.get_value(1) > 0){
            final PotionEffect espid = new PotionEffect(Potion.func_188412_a(1), 123456789, (speed.get_value(1)-1));
            espid.func_100012_b(true);
            MapEffectSpoofer.mc.field_71439_g.func_70690_d(espid);
        }
        // 'tren' (Strenght)
        if(strong.get_value(1) > 0){
            final PotionEffect tren = new PotionEffect(Potion.func_188412_a(5), 123456789, (strong.get_value(1)-1));
            tren.func_100012_b(true);
            MapEffectSpoofer.mc.field_71439_g.func_70690_d(tren);
        }
        // jeist (haste)
        if(haste.get_value(1) > 0){
            // (haste.get_value(1)-1) if for
            final PotionEffect jeist = new PotionEffect(Potion.func_188412_a(3), 123456789, (haste.get_value(1)-1));
            jeist.func_100012_b(true);
            MapEffectSpoofer.mc.field_71439_g.func_70690_d(jeist);
        }
    }
    @Override
    public void disable() {
        MapEffectSpoofer.mc.field_71439_g.func_184589_d(Potion.func_188412_a(1));
        MapEffectSpoofer.mc.field_71439_g.func_184589_d(Potion.func_188412_a(5));
        MapEffectSpoofer.mc.field_71439_g.func_184589_d(Potion.func_188412_a(3));
    }
}
