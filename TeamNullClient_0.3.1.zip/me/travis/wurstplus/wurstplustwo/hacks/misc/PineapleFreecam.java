package me.travis.wurstplus.wurstplustwo.hacks.misc;

import me.travis.wurstplus.wurstplustwo.event.WurstplusEventCancellable;
import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventPacket;
import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventPlayerTravel;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusMathUtil;
import me.zero.alpine.fork.listener.EventHandler;
import me.zero.alpine.fork.listener.Listener;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketInput;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.world.World;

public class PineapleFreecam extends WurstplusHack {

    private double posX;
    private double posY;
    private double posZ;
    private float pitch;
    private float yaw;
    private EntityOtherPlayerMP clonedPlayer;
    private boolean isRidingEntity;
    private Entity ridingEntity;

    public PineapleFreecam (){
        super(WurstplusCategory.WURSTPLUS_MISC);
        this.name = "Freecam";
        this.tag = "Freecam";
        this.description = "ecsplore a lot";
    }

    WurstplusSetting cancelpackets = create("Cancel Packets", "freecamcancelpackets", true);
    WurstplusSetting speed = create("Speed", "freecamspeed", 0.5, 0.1, 5.0);

    @Override
    public void update() {
        mc.field_71439_g.field_70145_X = true;
        mc.field_71439_g.func_70016_h(0, 0, 0);
        mc.field_71439_g.field_70747_aH = (float) speed.get_value(1);
        double[] dir = WurstplusMathUtil.directionSpeed(speed.get_value(1));
        if (mc.field_71439_g.field_71158_b.field_78902_a != 0 || mc.field_71439_g.field_71158_b.field_192832_b != 0) {
            mc.field_71439_g.field_70159_w = dir[0];
            mc.field_71439_g.field_70179_y = dir[1];
        } else {
            mc.field_71439_g.field_70159_w = 0;
            mc.field_71439_g.field_70179_y = 0;
        }

        mc.field_71439_g.func_70031_b(false);

        if (mc.field_71474_y.field_74314_A.func_151470_d()) {
            mc.field_71439_g.field_70181_x += speed.get_value(1.0);
        } else if (mc.field_71474_y.field_74311_E.func_151470_d()) {
            mc.field_71439_g.field_70181_x -= speed.get_value(1.0);
        }
    }

    @Override
    protected void enable() {
        if (mc.field_71439_g != null) {
            this.isRidingEntity = (mc.field_71439_g.func_184187_bx() != null);

            if (mc.field_71439_g.func_184187_bx() == null) {
                this.posX = mc.field_71439_g.field_70165_t;
                this.posY = mc.field_71439_g.field_70163_u;
                this.posZ = mc.field_71439_g.field_70161_v;
            } else {
                this.ridingEntity = mc.field_71439_g.func_184187_bx();
                mc.field_71439_g.func_184210_p();
            }

            this.pitch = mc.field_71439_g.field_70125_A;
            this.yaw = mc.field_71439_g.field_70177_z;

            (this.clonedPlayer = new EntityOtherPlayerMP((World)mc.field_71441_e, mc.func_110432_I().func_148256_e())).func_82149_j((Entity)mc.field_71439_g);
            this.clonedPlayer.field_70759_as = mc.field_71439_g.field_70759_as;

            mc.field_71441_e.func_73027_a(-100, (Entity)this.clonedPlayer);
            mc.field_71439_g.field_70145_X = true;
        }
    }

    @Override
    protected void disable() {
        if (mc.field_71439_g != null) {
            mc.field_71439_g.func_70080_a(this.posX, this.posY, this.posZ, this.yaw, this.pitch);
            mc.field_71441_e.func_73028_b(-100);
            this.clonedPlayer = null;

            this.posX = 0d;
            this.posY = 0d;
            this.posZ = 0d;
            this.yaw = 0f;
            this.pitch = 0f;

            mc.field_71439_g.field_71075_bZ.field_75100_b = false;
            mc.field_71439_g.field_71075_bZ.func_75092_a(0.05f);
            mc.field_71439_g.field_70145_X = false;

            final EntityPlayerSP player = mc.field_71439_g;
            final EntityPlayerSP player2 = mc.field_71439_g;
            final EntityPlayerSP player3 = mc.field_71439_g;
            player3.field_70179_y = 0d;
            player2.field_70181_x = 0d;
            player.field_70159_w = 0d;

            if (isRidingEntity) mc.field_71439_g.func_184205_a(ridingEntity, true);
        }

        mc.field_71438_f.func_72712_a();
    }

    @EventHandler
    private final Listener<WurstplusEventPacket.SendPacket> sendPacketListener = new Listener<>(event -> {
        if (cancelpackets.get_value(true) && (event.get_packet() instanceof CPacketPlayer || event.get_packet() instanceof CPacketInput)) {
            event.cancel();
        }
    });

    @EventHandler
    private final Listener<WurstplusEventPlayerTravel> travelListener = new Listener<>(event -> {
        if (event.get_era() != WurstplusEventCancellable.Era.EVENT_PRE) {
            return;
        }
        mc.field_71439_g.field_70145_X = true;
    });
} 