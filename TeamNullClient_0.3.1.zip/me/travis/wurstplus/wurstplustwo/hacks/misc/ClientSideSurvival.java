package me.travis.wurstplus.wurstplustwo.hacks.misc;

import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.world.GameType;

public class ClientSideSurvival extends WurstplusHack {
    public ClientSideSurvival() {
        super(WurstplusCategory.WURSTPLUS_MISC);
        this.name = "Client Side Survival";
        this.tag = "ClientSideSurvival";
        this.description = "makes your gamemode survival in client side";
    }

    @Override
    public void update() {
        if (mc.field_71439_g==null || mc.field_71442_b==null) return;
        if(!mc.field_71442_b.func_178889_l().equals(GameType.SURVIVAL)) {
            mc.field_71442_b.func_78746_a(GameType.SURVIVAL);
            mc.field_71439_g.func_71033_a(GameType.SURVIVAL);
        }
    }

    @Override
    protected void enable() {
        if (mc.field_71439_g==null || mc.field_71442_b==null) return;
        mc.field_71442_b.func_78746_a(GameType.SURVIVAL);
        mc.field_71439_g.func_71033_a(GameType.SURVIVAL);
    }
    public void disable() {
        if (mc.field_71439_g==null || mc.field_71442_b==null) return;
        if(!mc.field_71442_b.func_178889_l().equals(GameType.SURVIVAL)) {
            mc.field_71442_b.func_78746_a(GameType.SURVIVAL);
            mc.field_71439_g.func_71033_a(GameType.SURVIVAL);
    }  
  }
}
