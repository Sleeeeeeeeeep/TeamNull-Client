package me.travis.wurstplus.wurstplustwo.hacks.misc;

import java.util.ArrayList;

import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.util.math.BlockPos;
import java.util.List;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumFacing;
import net.minecraft.block.BlockCrops;
import java.util.Comparator;

import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;

public class AutoFarm extends WurstplusHack
{
    WurstplusSetting range;
    WurstplusSetting tickDelay;
    int waitCounter;
    
    public AutoFarm() {
        super(WurstplusCategory.WURSTPLUS_MISC);
        this.range = this.create("Range", "AutoFarmRange", 4.5, 0.0, 10.0);
        this.tickDelay = this.create("TickDelay", "AutoFarmTickDelay", 5, 0, 100);
        this.waitCounter = 0;
        this.name = "Auto Farm";
        this.tag = "AutoFarm";
        this.description = "i farm u";
    }
    
    @Override
    public void update() {
        final List<BlockPos> blockPosList = this.getSphere(getPlayerPos(), (float)this.range.get_value(1), 1, false, true, 0);
        blockPosList.stream().sorted(Comparator.comparing(b -> mc.field_71439_g.func_70011_f((double)b.func_177958_n(), (double)b.func_177956_o(), (double)b.func_177952_p()))).forEach(blockPos -> {
            if (mc.field_71441_e.func_180495_p(blockPos).func_177230_c() instanceof BlockCrops) {
                if (this.waitCounter < this.tickDelay.get_value(1)) {
                    ++this.waitCounter;
                }
                else {
                    mc.field_71442_b.func_180511_b(blockPos, EnumFacing.UP);
                    mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                    this.waitCounter = 0;
                }
            }
        });
    }
    
    public void enable() {
        this.waitCounter = 0;
    }
    
    public List<BlockPos> getSphere(final BlockPos loc, final float r, final int h, final boolean hollow, final boolean sphere, final int plus_y) {
        final List<BlockPos> circleblocks = new ArrayList<BlockPos>();
        final int cx = loc.func_177958_n();
        final int cy = loc.func_177956_o();
        final int cz = loc.func_177952_p();
        for (int x = cx - (int)r; x <= cx + r; ++x) {
            for (int z = cz - (int)r; z <= cz + r; ++z) {
                for (int y = sphere ? (cy - (int)r) : cy; y < (sphere ? (cy + r) : ((float)(cy + h))); ++y) {
                    final double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0);
                    if (dist < r * r && (!hollow || dist >= (r - 1.0f) * (r - 1.0f))) {
                        final BlockPos l = new BlockPos(x, y + plus_y, z);
                        circleblocks.add(l);
                    }
                }
            }
        }
        return circleblocks;
    }
    
    public static BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u), Math.floor(mc.field_71439_g.field_70161_v));
    }
}
