package me.travis.wurstplus.wurstplustwo.hacks.misc;

import cf.warriorcrystal.other.xulu.Wrapper;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.OnePopBlockInteractionHelper;
import me.travis.wurstplus.wurstplustwo.util.WurstplusBlockInteractHelper;
import me.travis.wurstplus.wurstplustwo.util.WurstplusEntityUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockFalling;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class Scaffold extends WurstplusHack {
    WurstplusSetting future = this.create("Ticks", "Ticks", 0, 0, 60);
    WurstplusSetting tower = this.create("Tower", "Tower", true);

    public Scaffold() {
        super(WurstplusCategory.WURSTPLUS_MISC);
        this.name = "Scaffold";
        this.tag = "Scaffold";
        this.description = "eskafol from cebe plos beonce";
    }

    @Override
    public void update() {
        if (mc.field_71439_g == null) {
            return;
        }
        Vec3d vec3d = WurstplusEntityUtil.getInterpolatedPos((Entity)mc.field_71439_g, this.future.get_value(0));
        BlockPos blockPos = new BlockPos(vec3d).func_177977_b();
        BlockPos belowBlockPos = blockPos.func_177977_b();
        if (!Wrapper.getWorld().func_180495_p(blockPos).func_185904_a().func_76222_j()) {
            return;
        }
        int newSlot = -1;
        for (int i = 0; i < 9; ++i) {
            Block block;
            ItemStack stack = Wrapper.getPlayer().field_71071_by.func_70301_a(i);
            if (stack == ItemStack.field_190927_a || !(stack.func_77973_b() instanceof ItemBlock) || OnePopBlockInteractionHelper.blackList.contains((Object)(block = ((ItemBlock)stack.func_77973_b()).func_179223_d())) || block instanceof BlockContainer || !Block.func_149634_a((Item)stack.func_77973_b()).func_176223_P().func_185913_b() || ((ItemBlock)stack.func_77973_b()).func_179223_d() instanceof BlockFalling && Wrapper.getWorld().func_180495_p(belowBlockPos).func_185904_a().func_76222_j()) continue;
            newSlot = i;
            break;
        }
        if (newSlot == -1) {
            return;
        }
        int oldSlot = Wrapper.getPlayer().field_71071_by.field_70461_c;
        Wrapper.getPlayer().field_71071_by.field_70461_c = newSlot;
        if (!OnePopBlockInteractionHelper.checkForNeighbours(blockPos)) {
            return;
        }
        OnePopBlockInteractionHelper.placeBlockScaffold(blockPos);
        Wrapper.getPlayer().field_71071_by.field_70461_c = oldSlot;
    }
}


