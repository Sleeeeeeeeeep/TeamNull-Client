package me.travis.wurstplus.wurstplustwo.hacks.combat;

import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusBlockUtil;
import me.travis.wurstplus.wurstplustwo.util.WurstplusMessageUtil;
import net.minecraft.block.BlockShulkerBox;
import net.minecraft.client.gui.GuiHopper;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;

import java.util.Objects;

public class WurstplusAuto32k extends WurstplusHack {

    public WurstplusAuto32k() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);

        this.name        = "Auto 32k";
        this.tag         = "Auto32k";
        this.description = "fastest in the west";
    }

    private BlockPos pos;

    private int hopper_slot;
    private int redstone_slot;
    private int shulker_slot;
    private int ticks_past;
    private int[] rot;

    private boolean setup;
    private boolean place_redstone;
    private boolean dispenser_done;
  
    WurstplusSetting place_mode = create("Place Mode", "AutotkPlaceMode", "Auto", combobox("Auto", "Looking", "Hopper"));
    WurstplusSetting swing = create("Swing", "AutotkSwing", "Mainhand", combobox("Mainhand", "Offhand", "Both", "None"));
    WurstplusSetting delay = create("Delay", "AutotkDelay", 4, 0, 10);
    WurstplusSetting rotate = create("Rotate", "Autotkrotate", false);
    WurstplusSetting debug = create("Debug", "AutotkDebug", false);

    @Override
    protected void enable() {

        ticks_past = 0;

        setup = false;
        dispenser_done = false;
        place_redstone = false;

        hopper_slot = -1;
        int dispenser_slot = -1;
        redstone_slot = -1;
        shulker_slot = -1;
        int block_slot = -1;

        for (int i = 0; i < 9; i++) {

            Item item = mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();

            if (item == Item.func_150898_a(Blocks.field_150438_bZ)) hopper_slot = i;
            else if (item == Item.func_150898_a(Blocks.field_150367_z)) dispenser_slot = i;
            else if (item == Item.func_150898_a(Blocks.field_150451_bX)) redstone_slot = i;
            else if (item instanceof ItemShulkerBox) shulker_slot = i;
            else if (item instanceof ItemBlock) block_slot = i;

        }

        if ((hopper_slot == -1 || dispenser_slot == -1 || redstone_slot == -1 || shulker_slot == -1 || block_slot == -1) && !place_mode.in("Hopper")) {
            WurstplusMessageUtil.send_client_message("missing item");
            this.set_disable();
            return;
        } else if (hopper_slot == -1 || shulker_slot == -1) {
            WurstplusMessageUtil.send_client_message("missing item");
            this.set_disable();
            return;
        }

        if (place_mode.in("Looking")) {

            RayTraceResult r = mc.field_71439_g.func_174822_a(5.0D, mc.func_184121_ak());

            pos = Objects.requireNonNull(r).func_178782_a().func_177984_a();

            double pos_x = (double) pos.func_177958_n() - mc.field_71439_g.field_70165_t;
            double pos_z = (double) pos.func_177952_p() - mc.field_71439_g.field_70161_v;

            rot = Math.abs(pos_x) > Math.abs(pos_z) ? (pos_x > 0.0D ? new int[] {-1, 0} : new int[] {1, 0}) : (pos_z > 0.0D ? new int[] {0, -1} : new int[] {0, 1});

            if (WurstplusBlockUtil.canPlaceBlock(this.pos) && WurstplusBlockUtil.isBlockEmpty(this.pos) && WurstplusBlockUtil.isBlockEmpty(this.pos.func_177982_a(this.rot[0], 0, this.rot[1])) &&
                    WurstplusBlockUtil.isBlockEmpty(this.pos.func_177982_a(0, 1, 0)) && WurstplusBlockUtil.isBlockEmpty(this.pos.func_177982_a(0, 2, 0)) && WurstplusBlockUtil.isBlockEmpty(this.pos.func_177982_a(this.rot[0], 1, this.rot[1]))) {

                WurstplusBlockUtil.placeBlock(pos, block_slot, rotate.get_value(true), false, swing);
                WurstplusBlockUtil.rotatePacket((double) this.pos.func_177982_a(-this.rot[0], 1, -this.rot[1]).func_177958_n() + 0.5D, this.pos.func_177956_o() + 1, (double) this.pos.func_177982_a(-this.rot[0], 1, -this.rot[1]).func_177952_p() + 0.5D);
                WurstplusBlockUtil.placeBlock(this.pos.func_177984_a(), dispenser_slot, false, false, swing);
                WurstplusBlockUtil.openBlock(this.pos.func_177984_a());

                setup = true;

            } else {
                WurstplusMessageUtil.send_client_message("unable to place");
                this.set_disable();
            }
        } else if (place_mode.in("Auto")) {
            for (int x = -2; x <= 2; x++) {
                for (int y = -1; y <= 1; y++) {
                    for (int z = -2; z <= 2; z++) {

                        this.rot = Math.abs(x) > Math.abs(z) ? (x > 0 ? new int[] {-1, 0} : new int[] {1, 0}) : (z > 0 ? new int[] {0, -1} : new int[] {0, 1});
                        this.pos = mc.field_71439_g.func_180425_c().func_177982_a(x, y, z);

                        if (mc.field_71439_g.func_174824_e(mc.func_184121_ak()).func_72438_d(mc.field_71439_g.func_174791_d().func_72441_c(x - rot[0] / 2f, (double) y + 0.5D, z + rot[1] / 2)) <= 4.5D && mc.field_71439_g.func_174824_e(mc.func_184121_ak()).func_72438_d(mc.field_71439_g.func_174791_d().func_72441_c((double) x + 0.5D, (double) y + 2.5D, (double) z + 0.5D)) <= 4.5D && WurstplusBlockUtil.canPlaceBlock(this.pos) && WurstplusBlockUtil.isBlockEmpty(this.pos) && WurstplusBlockUtil.isBlockEmpty(this.pos.func_177982_a(this.rot[0], 0, this.rot[1])) && WurstplusBlockUtil.isBlockEmpty(this.pos.func_177982_a(0, 1, 0)) && WurstplusBlockUtil.isBlockEmpty(this.pos.func_177982_a(0, 2, 0)) && WurstplusBlockUtil.isBlockEmpty(this.pos.func_177982_a(this.rot[0], 1, this.rot[1])))
                        {
                            WurstplusBlockUtil.placeBlock(this.pos, block_slot, rotate.get_value(true), false, swing);
                            WurstplusBlockUtil.rotatePacket((double) this.pos.func_177982_a(-this.rot[0], 1, -this.rot[1]).func_177958_n() + 0.5D, this.pos.func_177956_o() + 1, (double) this.pos.func_177982_a(-this.rot[0], 1, -this.rot[1]).func_177952_p() + 0.5D);
                            WurstplusBlockUtil.placeBlock(this.pos.func_177984_a(), dispenser_slot, false, false, swing);
                            WurstplusBlockUtil.openBlock(this.pos.func_177984_a());

                            setup = true;

                            return;
                        }

                    }
                }
            }
            WurstplusMessageUtil.send_client_message("unable to place");
            this.set_disable();
        } else {
            for (int z = -2; z <= 2; z++) {
                for (int y = -1; y <= 2; y++) {
                    for (int x = -2; x <= 2; x++) {
                        if ((z != 0 || y != 0 || x != 0) && (z != 0 || y != 1 || x != 0) && WurstplusBlockUtil.isBlockEmpty(mc.field_71439_g.func_180425_c().func_177982_a(z, y, x)) && mc.field_71439_g.func_174824_e(mc.func_184121_ak()).func_72438_d(mc.field_71439_g.func_174791_d().func_72441_c((double) z + 0.5D, (double) y + 0.5D, (double) x + 0.5D)) < 4.5D && WurstplusBlockUtil.isBlockEmpty(mc.field_71439_g.func_180425_c().func_177982_a(z, y + 1, x)) && mc.field_71439_g.func_174824_e(mc.func_184121_ak()).func_72438_d(mc.field_71439_g.func_174791_d().func_72441_c((double) z + 0.5D, (double) y + 1.5D, (double) x + 0.5D)) < 4.5D)  {

                            WurstplusBlockUtil.placeBlock(mc.field_71439_g.func_180425_c().func_177982_a(z, y, x), hopper_slot, rotate.get_value(true), false, swing);
                            WurstplusBlockUtil.placeBlock(mc.field_71439_g.func_180425_c().func_177982_a(z, y + 1, x), shulker_slot, rotate.get_value(true), false, swing);
                            WurstplusBlockUtil.openBlock(mc.field_71439_g.func_180425_c().func_177982_a(z, y, x));

                            pos = mc.field_71439_g.func_180425_c().func_177982_a(z, y, x);

                            dispenser_done = true;
                            place_redstone = true;
                            setup = true;

                            return;

                        }
                    }
                }
            }
        }
    }

    @Override
    public void update() {

        if (ticks_past > 50 && !(mc.field_71462_r instanceof GuiHopper)) {
            WurstplusMessageUtil.send_client_message("inactive too long, disabling");
            this.set_disable();
            return;
        }

        if (setup && ticks_past > this.delay.get_value(1)) {

            if (!dispenser_done) { // ching chong
                try {
                    mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71070_bA.field_75152_c, 36 + shulker_slot, 0, ClickType.QUICK_MOVE, mc.field_71439_g);
                    dispenser_done = true;
                    if (debug.get_value(true)) {
                        WurstplusMessageUtil.send_client_message("sent item");
                    }
                } catch (Exception ignored) {

                }
            }

            if (!place_redstone) {
                WurstplusBlockUtil.placeBlock(pos.func_177982_a(0, 2, 0), redstone_slot, rotate.get_value(true), false, swing);
                if (debug.get_value(true)) {
                    WurstplusMessageUtil.send_client_message("placed redstone");
                }
                place_redstone = true;
                return;
            }

            if (!place_mode.in("Hopper") && mc.field_71441_e.func_180495_p(this.pos.func_177982_a(this.rot[0], 1, this.rot[1])).func_177230_c() instanceof BlockShulkerBox
                    && mc.field_71441_e.func_180495_p(this.pos.func_177982_a(this.rot[0], 0, this.rot[1])).func_177230_c() != Blocks.field_150438_bZ
                    && place_redstone && dispenser_done && !(mc.field_71462_r instanceof GuiInventory)) {
                WurstplusBlockUtil.placeBlock(this.pos.func_177982_a(this.rot[0], 0, this.rot[1]), hopper_slot, rotate.get_value(true), false, swing);
                WurstplusBlockUtil.openBlock(this.pos.func_177982_a(this.rot[0], 0, this.rot[1]));
                if (debug.get_value(true)) {
                    WurstplusMessageUtil.send_client_message("in the hopper");
                }
            }

            if (mc.field_71462_r instanceof GuiHopper) {

                GuiHopper gui = (GuiHopper) mc.field_71462_r;

                int slot;
                for (slot = 32; slot <= 40; slot++) {
                    if (EnchantmentHelper.func_77506_a(Enchantments.field_185302_k, gui.field_147002_h.func_75139_a(slot).func_75211_c()) > 5)  {
                        mc.field_71439_g.field_71071_by.field_70461_c = slot - 32;
                        break;
                    }
                }

                if (!(gui.field_147002_h.field_75151_b.get(0).func_75211_c().func_77973_b() instanceof ItemAir)) {
                    boolean swapReady = true;
                    if (((GuiContainer)mc.field_71462_r).field_147002_h.func_75139_a(0).func_75211_c().field_190928_g) {
                        swapReady = false;
                    }
                    if (!((GuiContainer)mc.field_71462_r).field_147002_h.func_75139_a(shulker_slot + 32).func_75211_c().field_190928_g) {
                        swapReady = false;
                    }
                    if (swapReady) {
                        mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 0, shulker_slot, ClickType.SWAP, mc.field_71439_g);
                        this.disable();
                    }
                }

            }

        }

        ticks_past++;

    }

}
