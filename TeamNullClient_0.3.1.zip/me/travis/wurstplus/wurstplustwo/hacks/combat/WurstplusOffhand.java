package me.travis.wurstplus.wurstplustwo.hacks.combat;

import me.travis.wurstplus.Wurstplus;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusPlayerUtil;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;

public class WurstplusOffhand extends WurstplusHack {

    public WurstplusOffhand() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);

        this.name        = "Offhand";
        this.tag         = "Offhand";
        this.description = "Switches shit to ur offhand";
    }

    WurstplusSetting switch_mode = create("Offhand", "OffhandOffhand", "Totem", combobox("Totem", "Crystal", "Gapple"));
    WurstplusSetting totem_switch = create("Totem HP", "OffhandTotemHP", 16, 0, 36);

    WurstplusSetting gapple_in_hole = create("Gapple In Hole", "OffhandGapple", false);
    WurstplusSetting gapple_hole_hp = create("Gapple Hole HP", "OffhandGappleHP", 8, 0, 36);

    WurstplusSetting delay = create("Delay", "OffhandDelay", false);

    private boolean switching = false;
    private int last_slot;

    @Override
    public void update() {

        if (mc.field_71462_r == null || mc.field_71462_r instanceof GuiInventory) {

            if (switching) {
                swap_items(last_slot, 2);
                return;
            }

            float hp = mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj();

            if (hp > totem_switch.get_value(1)) {
                if (switch_mode.in("Crystal") && Wurstplus.get_hack_manager().get_module_with_tag("AutoCrystal").is_active()) {
                    swap_items(get_item_slot(Items.field_185158_cP),0);
                    return;
                }
                if (gapple_in_hole.get_value(true) && hp > gapple_hole_hp.get_value(1) && is_in_hole()) {
                    swap_items(get_item_slot(Items.field_151153_ao), delay.get_value(true) ? 1 : 0);
                    return;
                }
                if (switch_mode.in("Totem")) {
                    swap_items(get_item_slot(Items.field_190929_cY), delay.get_value(true) ? 1 : 0);
                    return;
                }
                if (switch_mode.in("Gapple")) {
                    swap_items(get_item_slot(Items.field_151153_ao), delay.get_value(true) ? 1 : 0);
                    return;
                }
                if (switch_mode.in("Crystal") && !Wurstplus.get_hack_manager().get_module_with_tag("AutoCrystal").is_active()) {
                    swap_items(get_item_slot(Items.field_190929_cY),0);
                    return;
                }
            } else {
                swap_items(get_item_slot(Items.field_190929_cY), delay.get_value(true) ? 1 : 0);
                return;
            }

            if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190931_a) {
                swap_items(get_item_slot(Items.field_190929_cY), delay.get_value(true) ? 1 : 0);
            }

        }

    }

    public void swap_items(int slot, int step) {
        if (slot == -1) return;
        if (step == 0) {
            mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, mc.field_71439_g);
            mc.field_71442_b.func_187098_a(0, 45, 0, ClickType.PICKUP, mc.field_71439_g);
            mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, mc.field_71439_g);
        }
        if (step == 1) {
            mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, mc.field_71439_g);
            switching = true;
            last_slot = slot;
        }
        if (step == 2) {
            mc.field_71442_b.func_187098_a(0, 45, 0, ClickType.PICKUP, mc.field_71439_g);
            mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, mc.field_71439_g);
            switching = false;
        }

        mc.field_71442_b.func_78765_e();
    }

    private boolean is_in_hole() {

        BlockPos player_block = WurstplusPlayerUtil.GetLocalPlayerPosFloored();

        return mc.field_71441_e.func_180495_p(player_block.func_177974_f()).func_177230_c() != Blocks.field_150350_a
                && mc.field_71441_e.func_180495_p(player_block.func_177976_e()).func_177230_c() != Blocks.field_150350_a
                && mc.field_71441_e.func_180495_p(player_block.func_177978_c()).func_177230_c() != Blocks.field_150350_a
                && mc.field_71441_e.func_180495_p(player_block.func_177968_d()).func_177230_c() != Blocks.field_150350_a;
    }


    private int get_item_slot(Item input) {
        if (input == mc.field_71439_g.func_184592_cb().func_77973_b()) return -1;
        for(int i = 36; i >= 0; i--) {
            final Item item = mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
            if(item == input) {
                if (i < 9) {
                    if (input == Items.field_151153_ao) {
                        return -1;
                    }
                    i += 36;
                }
                return i;
            }
        }
        return -1;
    }

}
