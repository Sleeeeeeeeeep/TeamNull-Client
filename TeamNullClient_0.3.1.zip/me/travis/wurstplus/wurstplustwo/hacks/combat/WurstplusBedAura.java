package me.travis.wurstplus.wurstplustwo.hacks.combat;

import me.travis.turok.draw.RenderHelp;
import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventRender;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusBlockInteractHelper;
import me.travis.wurstplus.wurstplustwo.util.WurstplusBlockUtil;
import me.travis.wurstplus.wurstplustwo.util.WurstplusFriendUtil;
import me.travis.wurstplus.wurstplustwo.util.WurstplusMessageUtil;
import net.minecraft.block.Block;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.BlockPos;

import java.util.stream.Collectors;

public class WurstplusBedAura extends WurstplusHack {

    public WurstplusBedAura() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);

        this.name        = "Bed Aura";
        this.tag         = "BedAura";
        this.description = "fucking endcrystal.me";
    }

    WurstplusSetting delay = create("Delay", "BedAuraDelay", 6, 0 , 20);
    WurstplusSetting range = create("Range", "BedAuraRange", 5, 0, 6);
    WurstplusSetting hard = create("Hard Rotate", "BedAuraRotate", false);
    WurstplusSetting swing = create("Swing", "BedAuraSwing", "Mainhand", combobox("Mainhand", "Offhand", "Both", "None"));

    private BlockPos render_pos;
    private int counter;
    private spoof_face spoof_looking;


    @Override
    protected void enable() {
        render_pos = null;
        counter = 0;
    }

    @Override
    protected void disable() {
        render_pos = null;
    }

    @Override
    public void update() {

        if (mc.field_71439_g == null) return;

        if (counter > delay.get_value(1)) {
            counter = 0;
            place_bed();
            break_bed();
            refill_bed();
        }

        counter++;

    }

    public void refill_bed() {
        if (!(mc.field_71462_r instanceof GuiContainer)) {
            if (is_space()) {
                for (int i = 9; i < 35; ++i) {
                    if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_151104_aV) {
                        mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, i, 0, ClickType.QUICK_MOVE, mc.field_71439_g);
                        break;
                    }
                }
            }
        }
    }

    private boolean is_space() {
        for (int i = 0; i < 9; i++) {
            if (mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75216_d()) {
                return true;
            }
        }
        return false;
    }

    public void place_bed() {

        if (find_bed() == -1) {
            return;
        }

        int bed_slot = find_bed();

        BlockPos best_pos = null;
        EntityPlayer best_target = null;
        float best_distance = (float) range.get_value(1);

        for (EntityPlayer player : mc.field_71441_e.field_73010_i.stream().filter(entityPlayer -> !WurstplusFriendUtil.isFriend(entityPlayer.func_70005_c_())).collect(Collectors.toList())) {

            if (player == mc.field_71439_g) continue;

            if (best_distance < mc.field_71439_g.func_70032_d(player)) continue;

            boolean face_place = true;

            BlockPos pos = get_pos_floor(player).func_177977_b();
            BlockPos pos2 = check_side_block(pos);

            if (pos2 != null) {
                best_pos = pos2.func_177984_a();
                best_target = player;
                best_distance = mc.field_71439_g.func_70032_d(player);
                face_place = false;
            }

            if (face_place) {
                BlockPos upos = get_pos_floor(player);
                BlockPos upos2 = check_side_block(upos);

                if (upos2 != null) {
                    best_pos = upos2.func_177984_a();
                    best_target = player;
                    best_distance = mc.field_71439_g.func_70032_d(player);
                }
            }
        }

        if (best_target == null) {
            return;
        }

        render_pos = best_pos;

        if (spoof_looking == spoof_face.NORTH) {
            if (hard.get_value(true)) {
                mc.field_71439_g.field_70177_z = 180;
            }
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Rotation(180, 0, mc.field_71439_g.field_70122_E));
        } else if (spoof_looking == spoof_face.SOUTH) {
            if (hard.get_value(true)) {
                mc.field_71439_g.field_70177_z = 0;
            }
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Rotation(0, 0, mc.field_71439_g.field_70122_E));
        } else if (spoof_looking == spoof_face.WEST) {
            if (hard.get_value(true)) {
                mc.field_71439_g.field_70177_z = 90;
            }
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Rotation(90, 0, mc.field_71439_g.field_70122_E));
        } else if (spoof_looking == spoof_face.EAST) {
            if (hard.get_value(true)) {
                mc.field_71439_g.field_70177_z = -90;
            }
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Rotation(-90, 0, mc.field_71439_g.field_70122_E));
        }

        WurstplusBlockUtil.placeBlock(best_pos, bed_slot, false, false, swing);

    }

    public void break_bed() {

        for (BlockPos pos : WurstplusBlockInteractHelper.getSphere(get_pos_floor(mc.field_71439_g), range.get_value(1), range.get_value(1), false, true, 0)
                .stream().filter(WurstplusBedAura::is_bed).collect(Collectors.toList())) {

            if (mc.field_71439_g.func_70093_af()) {
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
            }
            WurstplusBlockUtil.openBlock(pos);

        }

    }

    public int find_bed() {

        for (int i = 0; i < 9; i++) {
            if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_151104_aV) {
                return i;
            }
        }
        return -1;
    }

    public BlockPos check_side_block(BlockPos pos) {

        if (mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() != Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177974_f().func_177984_a()).func_177230_c() == Blocks.field_150350_a) {
            spoof_looking = spoof_face.WEST;
            return pos.func_177974_f();
        }
        if (mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() != Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177978_c().func_177984_a()).func_177230_c() == Blocks.field_150350_a) {
            spoof_looking = spoof_face.SOUTH;
            return pos.func_177978_c();
        }
        if (mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() != Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177976_e().func_177984_a()).func_177230_c() == Blocks.field_150350_a) {
            spoof_looking = spoof_face.EAST;
            return pos.func_177976_e();
        }
        if (mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() != Blocks.field_150350_a && mc.field_71441_e.func_180495_p(pos.func_177968_d().func_177984_a()).func_177230_c() == Blocks.field_150350_a) {
            spoof_looking = spoof_face.NORTH;
            return pos.func_177968_d();
        }

        return null;

    }

    public static BlockPos get_pos_floor(EntityPlayer player) {
        return new BlockPos(Math.floor(player.field_70165_t), Math.floor(player.field_70163_u), Math.floor(player.field_70161_v));
    }

    public static boolean is_bed(final BlockPos pos) {
        final Block block = mc.field_71441_e.func_180495_p(pos).func_177230_c();
        return block == Blocks.field_150324_C;
    }

    @Override
    public void render(WurstplusEventRender event) {

        if (render_pos == null) return;

        RenderHelp.prepare("lines");
        RenderHelp.draw_cube_line(RenderHelp.get_buffer_build(),
                render_pos.func_177958_n(), render_pos.func_177956_o(), render_pos.func_177952_p(),
            1, .2f, 1,
            255, 20, 20, 180,
            "all"
        );
        RenderHelp.release();


    }

    enum spoof_face {
        EAST,
        WEST,
        NORTH,
        SOUTH
    }

}
