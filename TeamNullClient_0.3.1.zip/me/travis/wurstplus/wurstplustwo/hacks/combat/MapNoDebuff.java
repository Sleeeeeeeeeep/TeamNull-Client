package me.travis.wurstplus.wurstplustwo.hacks.combat;

import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.init.MobEffects;

public class MapNoDebuff extends WurstplusHack {

    //Module Info
    public MapNoDebuff() {
        super(WurstplusCategory.WURSTPLUS_RENDER);

        this.name        = "No Debuff"; //Commands and Clickgui
        this.tag         = "AntiDebuff"; //Config and Arraylist
        this.description = "clean debuff efects"; //Useless but normally i add this
    }
    @Override
    public void update(){
        MapNoDebuff.mc.field_71439_g.func_184589_d(MobEffects.field_82731_v);
        MapNoDebuff.mc.field_71439_g.func_184589_d(MobEffects.field_76421_d);
        MapNoDebuff.mc.field_71439_g.func_184589_d(MobEffects.field_76431_k);
        MapNoDebuff.mc.field_71439_g.func_184589_d(MobEffects.field_76440_q);
        MapNoDebuff.mc.field_71439_g.func_184589_d(MobEffects.field_76437_t);
        MapNoDebuff.mc.field_71439_g.func_184589_d(MobEffects.field_76436_u);
    }
}