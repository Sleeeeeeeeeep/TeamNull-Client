package me.travis.wurstplus.wurstplustwo.hacks.combat;

import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusBlockInteractHelper;
import me.travis.wurstplus.wurstplustwo.util.WurstplusBlockInteractHelper.ValidResult;
import me.travis.wurstplus.wurstplustwo.util.WurstplusMessageUtil;
import me.travis.wurstplus.wurstplustwo.util.WurstplusPlayerUtil;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

import java.util.ArrayList;

public class WurstplusWebfill extends WurstplusHack {

    public WurstplusWebfill() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);

        this.name        = "Web Fill";
        this.tag         = "WebFill";
        this.description = "its like hole fill, but more annoying";
    }

    WurstplusSetting web_toggle = create("Toggle", "WebFillToggle", true);
    WurstplusSetting web_rotate = create("Rotate", "WebFillRotate", true);
    WurstplusSetting web_range = create("Range", "WebFillRange", 4, 1, 6);

    private final ArrayList<BlockPos> holes = new ArrayList<BlockPos>();

    private boolean sneak;

    @Override
    public void enable() {
        find_new_holes();
    }

    @Override
    public void disable() {
        holes.clear();
    }

    @Override
    public void update() {

        if (holes.isEmpty()) {

            if (!web_toggle.get_value(true)) {

                this.set_disable();
                WurstplusMessageUtil.toggle_message(this);
                return;

            } else {
                find_new_holes();
            }

        }

        BlockPos pos_to_fill = null;

        for (BlockPos pos : new ArrayList<BlockPos>(holes)) {

            if (pos == null) continue;

            WurstplusBlockInteractHelper.ValidResult result = WurstplusBlockInteractHelper.valid(pos);

            if (result != ValidResult.Ok) {

                holes.remove(pos);
                continue;

            }

            pos_to_fill = pos;
            break;

        }

        int obi_slot = find_in_hotbar();

        if (pos_to_fill != null && obi_slot != -1) {

            int last_slot = mc.field_71439_g.field_71071_by.field_70461_c;
            mc.field_71439_g.field_71071_by.field_70461_c = obi_slot;
            mc.field_71442_b.func_78765_e();

            if (place_blocks(pos_to_fill)) {
                holes.remove(pos_to_fill);
            }

            mc.field_71439_g.field_71071_by.field_70461_c = last_slot;

        }

    }

    public void find_new_holes() {

        holes.clear();

        for (BlockPos pos : WurstplusBlockInteractHelper.getSphere(WurstplusPlayerUtil.GetLocalPlayerPosFloored(), web_range.get_value(1), (int) web_range.get_value(1), false, true, 0)) {

            if (!mc.field_71441_e.func_180495_p(pos).func_177230_c().equals(Blocks.field_150350_a)) {
                continue;
            }

            if (!mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 1, 0)).func_177230_c().equals(Blocks.field_150350_a)) {
                continue;
            }

            if (!mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 2, 0)).func_177230_c().equals(Blocks.field_150350_a)) {
                continue;
            }

            boolean possible = true;

            for (BlockPos seems_blocks : new BlockPos[] {
                    new BlockPos( 0, -1,  0),
                    new BlockPos( 0,  0, -1),
                    new BlockPos( 1,  0,  0),
                    new BlockPos( 0,  0,  1),
                    new BlockPos(-1,  0,  0)
            }) {
                Block block = mc.field_71441_e.func_180495_p(pos.func_177971_a(seems_blocks)).func_177230_c();

                if (block != Blocks.field_150357_h && block != Blocks.field_150343_Z && block != Blocks.field_150477_bB && block != Blocks.field_150467_bQ) {
                    possible = false;

                    break;
                }

            }

            if (possible) {
                holes.add(pos);
            }

        }

    }

    private int find_in_hotbar() {

        for (int i = 0; i < 9; ++i) {

            final ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);

            if (stack.func_77973_b() == Item.func_150899_d(30)) {
                return i;
            }

        }
        return -1;
    }

    private boolean place_blocks(BlockPos pos) {

        if (!mc.field_71441_e.func_180495_p(pos).func_185904_a().func_76222_j()) {
            return false;
        }

        if (!WurstplusBlockInteractHelper.checkForNeighbours(pos)) {
            return false;
        }

        for (EnumFacing side : EnumFacing.values()) {

            Block neighborPos;
            BlockPos neighbor = pos.func_177972_a(side);

            EnumFacing side2 = side.func_176734_d();

            if (!WurstplusBlockInteractHelper.canBeClicked(neighbor)) continue;

            if (WurstplusBlockInteractHelper.blackList.contains((Object)(neighborPos = mc.field_71441_e.func_180495_p(neighbor).func_177230_c()))) {
                mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                sneak = true;
            }

            Vec3d hitVec = new Vec3d((Vec3i)neighbor).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(side2.func_176730_m()).func_186678_a(0.5));

            if (web_rotate.get_value(true)) {
                WurstplusBlockInteractHelper.faceVectorPacketInstant(hitVec);
            }

            mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
            mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);

            return true;
        }

        return false;

    }

}
