package me.travis.wurstplus.wurstplustwo.hacks.combat;

import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusBlockInteractHelper;
import me.travis.wurstplus.wurstplustwo.util.WurstplusBlockInteractHelper.ValidResult;
import me.travis.wurstplus.wurstplustwo.util.WurstplusBlockUtil;
import me.travis.wurstplus.wurstplustwo.util.WurstplusMathUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class WurstplusSelfTrap extends WurstplusHack {
    
    public WurstplusSelfTrap() {

        super(WurstplusCategory.WURSTPLUS_COMBAT);

		this.name        = "Self Trap";
		this.tag         = "SelfTrap";
		this.description = "oh 'eck, ive trapped me sen again";
    }

    WurstplusSetting toggle = create("Toggle", "SelfTrapToggle", false);
    WurstplusSetting rotate = create("Rotate", "SelfTrapRotate", false);
    WurstplusSetting swing = create("Swing", "SelfTrapSwing", "Mainhand", combobox("Mainhand", "Offhand", "Both", "None"));

    private BlockPos trap_pos;

    @Override
    protected void enable() {
        if (find_in_hotbar() == -1) {
            this.set_disable();
            return;
        }
    }

    @Override
    public void update() {
        final Vec3d pos = WurstplusMathUtil.interpolateEntity(mc.field_71439_g, mc.func_184121_ak());
        trap_pos = new BlockPos(pos.field_72450_a, pos.field_72448_b + 2, pos.field_72449_c);
        if (is_trapped()) {

            if (!toggle.get_value(true)) {
                toggle();
                return;
            } 

        }

        ValidResult result = WurstplusBlockInteractHelper.valid(trap_pos);

        if (result == ValidResult.AlreadyBlockThere && !mc.field_71441_e.func_180495_p(trap_pos).func_185904_a().func_76222_j()) {
            return;
        } 

        if (result == ValidResult.NoNeighbors) {

            BlockPos[] tests = {
                trap_pos.func_177978_c(),
                trap_pos.func_177968_d(),
                trap_pos.func_177974_f(),
                trap_pos.func_177976_e(),
                trap_pos.func_177984_a(),
                trap_pos.func_177977_b().func_177976_e() // ????? salhack is weird and i dont care enough to remove this. who the fuck uses this shit anyways fr fucking jumpy
            };

            for (BlockPos pos_ : tests) {

                ValidResult result_ = WurstplusBlockInteractHelper.valid(pos_);

                if (result_ == ValidResult.NoNeighbors || result_ == ValidResult.NoEntityCollision) continue;

                if (WurstplusBlockUtil.placeBlock(pos_, find_in_hotbar(), rotate.get_value(true), rotate.get_value(true), swing)) {
                    return;
                }

            }

            return;

        }

        WurstplusBlockUtil.placeBlock(trap_pos, find_in_hotbar(), rotate.get_value(true), rotate.get_value(true), swing);

    }

    public boolean is_trapped() {

        if (trap_pos == null) return false;

        IBlockState state = mc.field_71441_e.func_180495_p(trap_pos);

        return state.func_177230_c() != Blocks.field_150350_a && state.func_177230_c() != Blocks.field_150355_j && state.func_177230_c() != Blocks.field_150353_l;

    }

    private int find_in_hotbar() {

        for (int i = 0; i < 9; ++i) {

            final ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);

            if (stack != ItemStack.field_190927_a && stack.func_77973_b() instanceof ItemBlock) {

                final Block block = ((ItemBlock) stack.func_77973_b()).func_179223_d();

                if (block instanceof BlockEnderChest)
                    return i;
                
                else if (block instanceof BlockObsidian)
                    return i;
                
            }
        }
        return -1;
    }

}