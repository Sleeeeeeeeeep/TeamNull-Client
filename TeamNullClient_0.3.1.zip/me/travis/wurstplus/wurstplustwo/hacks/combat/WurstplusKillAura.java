package me.travis.wurstplus.wurstplustwo.hacks.combat;


import me.travis.wurstplus.Wurstplus;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusFriendUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

import java.util.stream.Collectors;


public class WurstplusKillAura extends WurstplusHack {

	public WurstplusKillAura() {
		super(WurstplusCategory.WURSTPLUS_COMBAT);

		this.name        = "Kill Aura";
		this.tag         = "KillAura";
		this.description = "To able hit enemies in a range.";
	}

	WurstplusSetting mode = create("Mode", "KillAuraMode", "A32k", combobox("A32k", "Normal"));
	WurstplusSetting player    = create("Player",   "KillAuraPlayer",  true);
	WurstplusSetting hostile   = create("Hostile",  "KillAuraHostile", false);
	WurstplusSetting sword     = create("Sword",    "KillAuraSword",   true);
	WurstplusSetting sync_tps  = create("Sync TPS", "KillAuraSyncTps", true);
	WurstplusSetting range     = create("Range",    "KillAuraRange",   5.0, 0.5, 6.0);
	WurstplusSetting delay = create("Delay", "KillAuraDelay", 2, 0, 10);

	boolean start_verify = true;

	EnumHand actual_hand = EnumHand.MAIN_HAND;

	double tick = 0;

	@Override
	protected void enable() {
		tick = 0;
	}

	@Override
	public void update() {
		if (mc.field_71439_g != null && mc.field_71441_e != null) {

			tick++;

			if (mc.field_71439_g.field_70128_L | mc.field_71439_g.func_110143_aJ() <= 0) {
				return;
			}

			if (mode.in("Normal")) {
				if (!(mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemSword) && sword.get_value(true)) {
					start_verify = false;
				} else if ((mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemSword) && sword.get_value(true)) {
					start_verify = true;
				} else if (!sword.get_value(true)) {
					start_verify = true;
				}

				Entity entity = find_entity();

				if (entity != null && start_verify) {
					// Tick.
					float tick_to_hit  = 20.0f - Wurstplus.get_event_handler().get_tick_rate();

					// If possible hit or no.
					boolean is_possible_attack = mc.field_71439_g.func_184825_o(sync_tps.get_value(true) ? -tick_to_hit : 0.0f) >= 1;

					// To hit if able.
					if (is_possible_attack) {
						attack_entity(entity);
					}
				}
			} else {

				if (!(mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemSword)) return;

				if (tick < delay.get_value(1)) return;

				tick = 0;

				Entity entity = find_entity();

				if (entity != null) {
					attack_entity(entity);
				}
			}

		}
	}

	public void attack_entity(Entity entity) {

		if (mode.in("A32k")) {

			int newSlot = -1;

			for (int i = 0; i < 9; i++) {
				ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
				if (stack == ItemStack.field_190927_a) {
					continue;
				}
				if (checkSharpness(stack)) {
					newSlot = i;
					break;
				}
			}

			if (newSlot != -1) {
				mc.field_71439_g.field_71071_by.field_70461_c = newSlot;
			}

		}

		// Get actual item off hand.
		ItemStack off_hand_item = mc.field_71439_g.func_184592_cb();

		// If off hand not null and is some SHIELD like use.
		if (off_hand_item.func_77973_b() == Items.field_185159_cQ) {
			// Ignore ant continue.
			mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, mc.field_71439_g.func_174811_aO()));
		}

		// Start hit on entity.
		mc.field_71439_g.field_71174_a.func_147297_a(new CPacketUseEntity(entity));
		mc.field_71439_g.func_184609_a(actual_hand);
		mc.field_71439_g.func_184821_cY();
	}

	// For find a entity.
	public Entity find_entity() {
		// Create a request.
		Entity entity_requested = null;

		for (Entity player : mc.field_71441_e.field_73010_i.stream().filter(entityPlayer -> !WurstplusFriendUtil.isFriend(entityPlayer.func_70005_c_())).collect(Collectors.toList())) {
			// If entity is not null continue to next event.
			if (player != null) {
				// If is compatible.
				if (is_compatible(player)) {
					// If is possible to get.
					if (mc.field_71439_g.func_70032_d(player) <= range.get_value(1.0)) {
						// Atribute the entity into entity_requested.
						entity_requested = player;
					}
				}
			}
		}

		// Return the entity requested.
		return entity_requested;
	}

	// Compatible or no.
	public boolean is_compatible(Entity entity) {
		// Instend entity with some type entity to continue or no.
		if (player.get_value(true) && entity instanceof EntityPlayer) {
			if (entity != mc.field_71439_g && !(entity.func_70005_c_().equals(mc.field_71439_g.func_70005_c_())) /* && WurstplusFriendManager.is_friend(entity) == false */) {
				return true;
			}
		}

		// If is hostile.
		if (hostile.get_value(true) && entity instanceof IMob) {
			return true;
		}

		// If entity requested die.
		if (entity instanceof EntityLivingBase) {
			EntityLivingBase entity_living_base = (EntityLivingBase) entity;

			if (entity_living_base.func_110143_aJ() <= 0) {
				return false;
			}
		}

		// Return false.
		return false;
	}

	private boolean checkSharpness(ItemStack stack) {

		if (stack.func_77978_p() == null) {
			return false;
		}

		NBTTagList enchants = (NBTTagList) stack.func_77978_p().func_74781_a("ench");

		if (enchants == null) {
			return false;
		}

		for (int i = 0; i < enchants.func_74745_c(); i++) {
			NBTTagCompound enchant = enchants.func_150305_b(i);
			if (enchant.func_74762_e("id") == 16) {
				int lvl = enchant.func_74762_e("lvl");
				if (lvl > 5) {
					return true;
				}
				break;
			}
		}

		return false;

	}
}