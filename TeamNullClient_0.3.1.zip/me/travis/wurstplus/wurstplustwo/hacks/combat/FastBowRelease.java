package me.travis.wurstplus.wurstplustwo.hacks.combat;

import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBow;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.math.BlockPos;
import me.zero.alpine.fork.listener.EventHandler;
import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventPacket;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.zero.alpine.fork.listener.Listener;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;

public class FastBowRelease extends WurstplusHack{
    public FastBowRelease() {

        super(WurstplusCategory.WURSTPLUS_COMBAT);

        this.name = "Fast Bow";
        this.tag = "FastBow";
        this.description = "metralleta bow";
    } //                                  xoffu W+3
        WurstplusSetting ticks = create("Ticks", "release", 1.0d, 1.0d, 25.0d);
	
	@EventHandler
    public Listener<WurstplusEventPacket.SendPacket> listener;
	
    
    @Override
    public void update() {
        Double FinalTimeout = ticks.get_value(1) + 1.15D;
        long timeout = FinalTimeout.longValue();
        Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemBow && mc.field_71439_g.func_184587_cr() && (double) mc.field_71439_g.func_184612_cw() >= FinalTimeout) {
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, mc.field_71439_g.func_174811_aO()));
            mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayerTryUseItem(mc.field_71439_g.func_184600_cs()));
            mc.field_71439_g.func_184597_cx();
        }
    }
}