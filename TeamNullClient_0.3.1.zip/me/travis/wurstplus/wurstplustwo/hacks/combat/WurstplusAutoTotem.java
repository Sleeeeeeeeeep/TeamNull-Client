package me.travis.wurstplus.wurstplustwo.hacks.combat;

import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;

public class WurstplusAutoTotem extends WurstplusHack {

    public WurstplusAutoTotem() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);

        this.name        = "Auto Totem";
        this.tag         = "AutoTotem";
        this.description = "put totem in offhand";
    }

    WurstplusSetting delay = create("Delay", "TotemDelay", false);

    private boolean switching = false;
    private int last_slot;

    @Override
    public void update() {

        if (mc.field_71462_r == null || mc.field_71462_r instanceof GuiInventory) {

            if (switching) {
                swap_items(last_slot, 2);
                return;
            }

            if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190931_a) {
                swap_items(get_item_slot(), delay.get_value(true) ? 1 : 0);
            }

        }

    }

    private int get_item_slot() {
        if (Items.field_190929_cY == mc.field_71439_g.func_184592_cb().func_77973_b()) return -1;
        for(int i = 36; i >= 0; i--) {
            final Item item = mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
            if(item == Items.field_190929_cY) {
                if (i < 9) {
                    return -1;
                }
                return i;
            }
        }
        return -1;
    }

    public void swap_items(int slot, int step) {
        if (slot == -1) return;
        if (step == 0) {
            mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, mc.field_71439_g);
            mc.field_71442_b.func_187098_a(0, 45, 0, ClickType.PICKUP, mc.field_71439_g);
            mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, mc.field_71439_g);
        }
        if (step == 1) {
            mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, mc.field_71439_g);
            switching = true;
            last_slot = slot;
        }
        if (step == 2) {
            mc.field_71442_b.func_187098_a(0, 45, 0, ClickType.PICKUP, mc.field_71439_g);
            mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.PICKUP, mc.field_71439_g);
            switching = false;
        }

        mc.field_71442_b.func_78765_e();
    }

}
