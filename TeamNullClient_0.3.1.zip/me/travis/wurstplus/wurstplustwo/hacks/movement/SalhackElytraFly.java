package me.travis.wurstplus.wurstplustwo.hacks.movement;

import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;

import me.travis.wurstplus.Wurstplus;
import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventPlayerTravel;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusMathUtil;
import me.travis.wurstplus.wurstplustwo.util.WurstplusTimer;
import me.zero.alpine.fork.listener.EventHandler;
import me.zero.alpine.fork.listener.Listener;

public final class SalhackElytraFly extends WurstplusHack{
    public SalhackElytraFly() {
        
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);

        this.name = "Sal E Fly";
        this.tag = "SalEFly";
        this.description = "best elytrafly ever?";
    }

    WurstplusSetting mode = create("Mode", "Mode", "Control", combobox("Normal", "Tarzan", "Superior", "Packet", "Control"));
    WurstplusSetting speed = create("Speed", "Speed", 1.81f, 0f, 5f);
    WurstplusSetting down_speed = create("Down Speed", "DownSpeed", 1f, 0f, 5f);
    WurstplusSetting glide_speed = create("Glide Speed", "GlideSpeed", 1f, 0f, 5f);
    WurstplusSetting up_speed = create("Up Speed", "UpSpeed", 1f, 0f, 5f);
    WurstplusSetting acelerate = create("Acelerate", "Acelerate", true);
    WurstplusSetting aceleration_timer = create("Aceleration", "AcelerationTimer", 1000, 0, 10000);
    WurstplusSetting water_cancel = create("Cancel in Water", "CancelInWater", true);
    WurstplusSetting auto_fly = create("Instant Fly", "InstantFly", true);
    WurstplusSetting auto_elytra = create("Equip Elytra", "EquipElytra", true);
    
    private WurstplusTimer AccelerationTimer = new WurstplusTimer();
    private WurstplusTimer AccelerationResetTimer = new WurstplusTimer();
    private WurstplusTimer InstantFlyTimer = new WurstplusTimer();
    private WurstplusHack PacketFly = null;
    private int ElytraSlot = -1;
    
    @Override
    public void enable()
    {
        super.enable();
        
        PacketFly = Wurstplus.get_hack_manager().get_module_with_tag("PacketFly");
        
        ElytraSlot = -1;
        
        if (auto_elytra.get_value(true))
        {
            if (mc.field_71439_g != null && mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() != Items.field_185160_cR)
            {
                for (int l_I = 0; l_I < 44; ++l_I)
                {
                    ItemStack l_Stack = mc.field_71439_g.field_71071_by.func_70301_a(l_I);
                    
                    if (l_Stack.func_190926_b() || l_Stack.func_77973_b() != Items.field_185160_cR)
                        continue;
                    
                    ItemElytra l_Elytra = (ItemElytra)l_Stack.func_77973_b();
                    
                    ElytraSlot = l_I;
                    break;
                }
                
                if (ElytraSlot != -1)
                {
                    boolean l_HasArmorAtChest = mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() != Items.field_190931_a;
                    
                    mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, ElytraSlot, 0, ClickType.PICKUP, mc.field_71439_g);
                    mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, 6, 0, ClickType.PICKUP, mc.field_71439_g);
                    
                    if (l_HasArmorAtChest)
                        mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, ElytraSlot, 0, ClickType.PICKUP, mc.field_71439_g);
                }
            }
        }
    }

    @Override
    public void disable()
    {
        super.disable();
        
        if (mc.field_71439_g == null)
            return;
        
        if (ElytraSlot != -1)
        {
            boolean l_HasItem = !mc.field_71439_g.field_71071_by.func_70301_a(ElytraSlot).func_190926_b() || mc.field_71439_g.field_71071_by.func_70301_a(ElytraSlot).func_77973_b() != Items.field_190931_a;
            
            mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, 6, 0, ClickType.PICKUP, mc.field_71439_g);
            mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, ElytraSlot, 0, ClickType.PICKUP, mc.field_71439_g);
            
            if (l_HasItem)
                mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, 6, 0, ClickType.PICKUP, mc.field_71439_g);
        }
    }
    public String getMetaData()
    {
        return this.mode.get_current_value();
    }

    @EventHandler
    private Listener<WurstplusEventPlayerTravel> OnTravel = new Listener<>(p_Event ->
    {
        if (mc.field_71439_g == null || PacketFly.is_active()) ///< Ignore if Flight is on: ex flat flying
            return;

        /// Player must be wearing an elytra.
        if (mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() != Items.field_185160_cR)
            return;

        if (!mc.field_71439_g.func_184613_cA())
        {
            if (!mc.field_71439_g.field_70122_E && auto_fly.get_value(true))
            {
                if (!InstantFlyTimer.passed(1000))
                    return;

                InstantFlyTimer.reset();

                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketEntityAction(mc.field_71439_g, Action.START_FALL_FLYING));
            }

            return;
        }

        switch (mode.get_current_value())
        {
            case "Normal":
            case "Tarzan":
            case "Packet":
                HandleNormalModeElytra(p_Event);
                break;
            case "Superior":
                HandleImmediateModeElytra(p_Event);
                break;
            case "Control":
                HandleControlMode(p_Event);
                break;
            default:
                break;
        }
    });

    public void HandleNormalModeElytra(WurstplusEventPlayerTravel p_Travel)
    {

        boolean l_IsMoveKeyDown = mc.field_71439_g.field_71158_b.field_192832_b > 0 || mc.field_71439_g.field_71158_b.field_78902_a > 0;

        boolean l_CancelInWater = !mc.field_71439_g.func_70090_H() && !mc.field_71439_g.func_180799_ab() && water_cancel.get_value(true);
        
        if (mc.field_71439_g.field_71158_b.field_78901_c)
        {
            p_Travel.cancel();
            Accelerate();
            return;
        }
        else if (mode.in("Tarzan") && l_CancelInWater ){
            if (acelerate.get_value(true))
            {
                if (AccelerationTimer.passed(aceleration_timer.get_value(1)))
                {
                    Accelerate();
                    return;
                }
            }
            return;
        }

        p_Travel.cancel();
        Accelerate();
    }

    public void HandleImmediateModeElytra(WurstplusEventPlayerTravel p_Travel)
    {
        if (mc.field_71439_g.field_71158_b.field_78901_c)
        {
            double l_MotionSq = Math.sqrt(mc.field_71439_g.field_70159_w * mc.field_71439_g.field_70159_w + mc.field_71439_g.field_70179_y * mc.field_71439_g.field_70179_y);
            
            if (l_MotionSq > 1.0)
            {
                return;
            }
            else
            {
                double[] dir = WurstplusMathUtil.directionSpeedNoForward(speed.get_value(1));
                
                mc.field_71439_g.field_70159_w = dir[0];
                mc.field_71439_g.field_70181_x = -(glide_speed.get_value(1) / 10000f);
                mc.field_71439_g.field_70179_y = dir[1];
            }

            p_Travel.cancel();
            return;
        }
        
        mc.field_71439_g.func_70016_h(0, 0, 0);

        p_Travel.cancel();
        double[] dir = WurstplusMathUtil.directionSpeed(speed.get_value(1));

        if (mc.field_71439_g.field_71158_b.field_78902_a != 0 || mc.field_71439_g.field_71158_b.field_192832_b != 0)
        {
            mc.field_71439_g.field_70159_w = dir[0];
            mc.field_71439_g.field_70181_x = -(glide_speed.get_value(1) / 10000f);
            mc.field_71439_g.field_70179_y = dir[1];
        }

        if (mc.field_71439_g.field_71158_b.field_78899_d)
            mc.field_71439_g.field_70181_x = -down_speed.get_value(1);
        
        mc.field_71439_g.field_184618_aE = 0;
        mc.field_71439_g.field_70721_aZ = 0;
        mc.field_71439_g.field_184619_aG = 0;
    }

    public void Accelerate()
    {
        if (AccelerationResetTimer.passed(aceleration_timer.get_value(1)))
        {
            AccelerationResetTimer.reset();
            AccelerationTimer.reset();
        }

        float l_Speed = this.speed.get_value(1);

        final double[] dir = WurstplusMathUtil.directionSpeed(l_Speed);

        mc.field_71439_g.field_70181_x = -(glide_speed.get_value(1) / 10000f);

        if (mc.field_71439_g.field_71158_b.field_78902_a != 0 || mc.field_71439_g.field_71158_b.field_192832_b != 0)
        {
            mc.field_71439_g.field_70159_w = dir[0];
            mc.field_71439_g.field_70179_y = dir[1];
        }
        else
        {
            mc.field_71439_g.field_70159_w = 0;
            mc.field_71439_g.field_70179_y = 0;
        }

        if (mc.field_71439_g.field_71158_b.field_78899_d)
            mc.field_71439_g.field_70181_x = -down_speed.get_value(1);

        mc.field_71439_g.field_184618_aE = 0;
        mc.field_71439_g.field_70721_aZ = 0;
        mc.field_71439_g.field_184619_aG = 0;
    }


    private void HandleControlMode(WurstplusEventPlayerTravel p_Event)
    {
        final double[] dir = WurstplusMathUtil.directionSpeed(speed.get_value(1));
        
        if (mc.field_71439_g.field_71158_b.field_78902_a != 0 || mc.field_71439_g.field_71158_b.field_192832_b != 0)
        {
            mc.field_71439_g.field_70159_w = dir[0];
            mc.field_71439_g.field_70179_y = dir[1];
            
            mc.field_71439_g.field_70159_w -= (mc.field_71439_g.field_70159_w*(Math.abs(mc.field_71439_g.field_70125_A)+90)/90) - mc.field_71439_g.field_70159_w;
            mc.field_71439_g.field_70179_y -= (mc.field_71439_g.field_70179_y*(Math.abs(mc.field_71439_g.field_70125_A)+90)/90) - mc.field_71439_g.field_70179_y;
        }
        else
        {
            mc.field_71439_g.field_70159_w = 0;
            mc.field_71439_g.field_70179_y = 0;
        }
        
        mc.field_71439_g.field_70181_x = (-WurstplusMathUtil.degToRad(mc.field_71439_g.field_70125_A)) * mc.field_71439_g.field_71158_b.field_192832_b;
        

        mc.field_71439_g.field_184618_aE = 0;
        mc.field_71439_g.field_70721_aZ = 0;
        mc.field_71439_g.field_184619_aG = 0;
        p_Event.cancel();
    }
}
