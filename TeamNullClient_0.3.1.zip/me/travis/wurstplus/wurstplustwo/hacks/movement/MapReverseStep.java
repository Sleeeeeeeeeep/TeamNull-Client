package me.travis.wurstplus.wurstplustwo.hacks.movement;

import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.util.math.AxisAlignedBB;

public class MapReverseStep extends WurstplusHack {
    
    public MapReverseStep() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);

		this.name        = "Reverse Step";
		this.tag         = "ReverseStep";
		this.description = "anashei";
    }

    @Override
    public void update() {

    if (!mc.field_71439_g.field_70122_E || mc.field_71439_g.func_70617_f_() || mc.field_71439_g.func_70090_H() || mc.field_71439_g.field_70134_J || mc.field_71439_g.func_180799_ab()  || mc.field_71439_g.field_71158_b.field_78901_c || mc.field_71439_g.field_70145_X) return;
    if (mc.field_71439_g.field_191988_bg == 0 && mc.field_71439_g.field_70702_br == 0) return;
    
    final double n = get_n_normal();
    mc.field_71439_g.field_70181_x = -1;
    }
    public double get_n_normal() {
        
        mc.field_71439_g.field_70138_W = 0.5f;

        double max_y = -1;

        final AxisAlignedBB grow = mc.field_71439_g.func_174813_aQ().func_72317_d(0, 0.05, 0).func_186662_g(0.05);

        if (!mc.field_71441_e.func_184144_a(mc.field_71439_g, grow.func_72317_d(0, 2, 0)).isEmpty()) return 100;

        for (final AxisAlignedBB aabb : mc.field_71441_e.func_184144_a(mc.field_71439_g, grow)) {

            if (aabb.field_72337_e > max_y) {
                max_y = aabb.field_72337_e;
            }

        }
        return max_y - mc.field_71439_g.field_70163_u;
    }
}
    