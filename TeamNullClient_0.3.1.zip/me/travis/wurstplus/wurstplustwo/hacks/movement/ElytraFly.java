package me.travis.wurstplus.wurstplustwo.hacks.movement;

import me.travis.wurstplus.Wurstplus;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusMathUtil;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;

public class ElytraFly extends WurstplusHack {
// i break it too
        WurstplusSetting speed = create("Speed", "ElytraFlySpeed", 1.81, 0.5, 10.0);
        WurstplusSetting upspeed = create("Up Speed", "ElytraFlyUpSpeed", 1, 0, 10);
        WurstplusSetting downspeed = create("Down Speed", "ElytraFlyDownSpeed", 1, 0, 10);
        WurstplusSetting timer = create("On Air Timer", "ElytraFlyOnAirTimer", 0.5f, 0.5f, 10f);

    public ElytraFly() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);
        this.name = "Elytra Fly";
        this.tag = "ElytraFly";
        this.description = "fly with elytras";
    }

    @Override
    public void enable() {
        if (this.mc.field_71439_g == null) {
            return;
        }

    }

    @Override
    public void disable() {
        mc.field_71428_T.field_194149_e = 50;
    }

    @Override
    public void update() {

        if(this.mc.field_71439_g.field_70122_E)
            mc.field_71428_T.field_194149_e = 50;
        else
        if(mc.field_71439_g.func_184613_cA())
            mc.field_71428_T.field_194149_e = 50;
        else

                mc.field_71428_T.field_194149_e = 170.0f / timer.get_value(0);



        if (this.mc.field_71439_g == null) {
            return;
        }
        if (this.mc.field_71439_g.func_184613_cA()) {
            final double[] forwardDirectionSpeed = WurstplusMathUtil.directionSpeed(this.speed.get_value(0));
            this.mc.field_71439_g.func_70016_h(0.0, 0.0, 0.0);
            if (this.mc.field_71474_y.field_74314_A.func_151470_d()) {
                final EntityPlayerSP player = this.mc.field_71439_g;
                player.field_70181_x += this.upspeed.get_value(0);
            }
            if (this.mc.field_71474_y.field_74311_E.func_151470_d()) {
                final EntityPlayerSP player2 = this.mc.field_71439_g;
                player2.field_70181_x -= this.downspeed.get_value(0);
            }
            if (this.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f || this.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f) {
                this.mc.field_71439_g.field_70159_w = forwardDirectionSpeed[0];
                this.mc.field_71439_g.field_70179_y = forwardDirectionSpeed[1];
            }
            else {
                this.mc.field_71439_g.field_70159_w = 0.0;
                this.mc.field_71439_g.field_70179_y = 0.0;
            }
        }
    }
}
