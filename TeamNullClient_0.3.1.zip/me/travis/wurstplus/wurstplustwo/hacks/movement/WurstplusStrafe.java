package me.travis.wurstplus.wurstplustwo.hacks.movement;

import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventMove;
import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventPlayerJump;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.zero.alpine.fork.listener.EventHandler;
import me.zero.alpine.fork.listener.Listener;
import net.minecraft.init.MobEffects;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;


public class WurstplusStrafe extends WurstplusHack {

	public WurstplusStrafe() {
		super(WurstplusCategory.WURSTPLUS_MOVEMENT);

		this.name        = "Strafe";
		this.tag         = "Strafe";
		this.description = "its like running, but faster";
	}

	WurstplusSetting speed_mode = create("Mode", "StrafeMode", "Strafe", combobox("Strafe", "On Ground"));
	WurstplusSetting auto_sprint = create("Auto Sprint", "StrafeSprint", true);
	WurstplusSetting on_water = create("On Water", "StrafeOnWater", true);
	WurstplusSetting auto_jump = create("Auto Jump", "StrafeAutoJump", true);
	WurstplusSetting backward = create("Backwards", "StrafeBackwards", true);
	WurstplusSetting bypass = create("Bypass", "StrafeBypass", false);

	@Override
	public void update() {
		
		if (mc.field_71439_g.func_184218_aH()) return;

		if (mc.field_71439_g.func_70090_H() || mc.field_71439_g.func_180799_ab()) {
			if (!on_water.get_value(true)) return;
		}

		if (mc.field_71439_g.field_191988_bg != 0 || mc.field_71439_g.field_70702_br != 0) {

			if (mc.field_71439_g.field_191988_bg < 0 && !backward.get_value(true)) return;

			if (auto_sprint.get_value(true)) {
				mc.field_71439_g.func_70031_b(true);
			}

			if (mc.field_71439_g.field_70122_E && speed_mode.in("Strafe")) {

				if (auto_jump.get_value(true)) {
					mc.field_71439_g.field_70181_x = 0.405f;
				}

				final float yaw = get_rotation_yaw() * 0.017453292F;
				mc.field_71439_g.field_70159_w -= MathHelper.func_76126_a(yaw) * 0.2f;
				mc.field_71439_g.field_70179_y += MathHelper.func_76134_b(yaw) * 0.2f;

			} else if (mc.field_71439_g.field_70122_E && speed_mode.in("On Ground")) {

				final float yaw = get_rotation_yaw();
                mc.field_71439_g.field_70159_w -= MathHelper.func_76126_a(yaw) * 0.2f;
                mc.field_71439_g.field_70179_y += MathHelper.func_76134_b(yaw) * 0.2f;
				mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u+0.4, mc.field_71439_g.field_70161_v, false));
				
			}

		}

		if (mc.field_71474_y.field_74314_A.func_151470_d() && mc.field_71439_g.field_70122_E) {
			mc.field_71439_g.field_70181_x = 0.405f;
		}

	}

	@EventHandler
	private Listener<WurstplusEventPlayerJump> on_jump = new Listener<>(event -> {

		if (speed_mode.in("Strafe")) {
			event.cancel();
		}

	});

	@EventHandler
	private Listener<WurstplusEventMove> player_move = new Listener<>(event -> {

		if (speed_mode.in("On Ground")) return;

		if (mc.field_71439_g.func_70090_H() || mc.field_71439_g.func_180799_ab()) {
			if (!speed_mode.get_value(true)) return;
		}

		if (mc.field_71439_g.func_70093_af() || mc.field_71439_g.func_70617_f_() || mc.field_71439_g.field_70134_J || mc.field_71439_g.func_180799_ab() || mc.field_71439_g.func_70090_H() || mc.field_71439_g.field_71075_bZ.field_75100_b) return;

		float player_speed = 0.2873f;
		float move_forward = mc.field_71439_g.field_71158_b.field_192832_b;
		float move_strafe = mc.field_71439_g.field_71158_b.field_78902_a;
		float rotation_yaw = mc.field_71439_g.field_70177_z;

		if (mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
			final int amp = mc.field_71439_g.func_70660_b(MobEffects.field_76424_c).func_76458_c();
			player_speed *= (1.2f * (amp+1));
		}

		if (!bypass.get_value(true)) {
			player_speed *= 1.0064f;
		}

		if (move_forward == 0 && move_strafe == 0) {
			event.set_x(0.0d);
			event.set_z(0.0d);
		} else {
			if (move_forward != 0.0f) {
                if (move_strafe > 0.0f) {
                    rotation_yaw += ((move_forward > 0.0f) ? -45 : 45);
                } else if (move_strafe < 0.0f) {
                    rotation_yaw += ((move_forward > 0.0f) ? 45 : -45);
                }
                move_strafe = 0.0f;
                if (move_forward > 0.0f) {
                    move_forward = 1.0f;
                } else if (move_forward < 0.0f) {
                    move_forward = -1.0f;
                }
			}

            event.set_x((move_forward * player_speed) * Math.cos(Math.toRadians((rotation_yaw + 90.0f))) + (move_strafe * player_speed) * Math.sin(Math.toRadians((rotation_yaw + 90.0f))));
            event.set_z((move_forward * player_speed) * Math.sin(Math.toRadians((rotation_yaw + 90.0f))) - (move_strafe * player_speed) * Math.cos(Math.toRadians((rotation_yaw + 90.0f))));

		}

		event.cancel();

	});

	private float get_rotation_yaw() {
		float rotation_yaw = mc.field_71439_g.field_70177_z;
        if (mc.field_71439_g.field_191988_bg < 0.0f) {
            rotation_yaw += 180.0f;
        }
        float n = 1.0f;
        if (mc.field_71439_g.field_191988_bg < 0.0f) {
            n = -0.5f;
        }
        else if (mc.field_71439_g.field_191988_bg > 0.0f) {
            n = 0.5f;
        }
        if (mc.field_71439_g.field_70702_br > 0.0f) {
            rotation_yaw -= 90.0f * n;
        }
        if (mc.field_71439_g.field_70702_br < 0.0f) {
            rotation_yaw += 90.0f * n;
        }
        return rotation_yaw * 0.017453292f;
	}

}