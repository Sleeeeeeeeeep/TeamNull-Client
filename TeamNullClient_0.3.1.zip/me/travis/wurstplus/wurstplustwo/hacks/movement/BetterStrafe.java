package me.travis.wurstplus.wurstplustwo.hacks.movement;

import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.math.MathHelper;

public class BetterStrafe
        extends WurstplusHack {
    int waitCounter;
    int forward;

    public BetterStrafe() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);
        this.name = "Better Strafe";
        this.tag = "BetterStrafe";
        this.description = "strafe but better";
        this.forward = 1;
    }

    WurstplusSetting autojump = this.create("AutoJump", "StrafeAutoJump", true);

    @Override
    public void update() {
        boolean boost;
        boolean bl = boost = Math.abs(BetterStrafe.mc.field_71439_g.field_70759_as - BetterStrafe.mc.field_71439_g.field_70177_z) < 90.0f;
        if (BetterStrafe.mc.field_71439_g.field_191988_bg != 0.0f) {
            if (!BetterStrafe.mc.field_71439_g.func_70051_ag()) {
                BetterStrafe.mc.field_71439_g.func_70031_b(true);
            }
            float yaw = BetterStrafe.mc.field_71439_g.field_70177_z;
            if (BetterStrafe.mc.field_71439_g.field_191988_bg > 0.0f) {
                if (BetterStrafe.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f) {
                    yaw += BetterStrafe.mc.field_71439_g.field_71158_b.field_78902_a > 0.0f ? -45.0f : 45.0f;
                }
                this.forward = 1;
                BetterStrafe.mc.field_71439_g.field_191988_bg = 1.0f;
                BetterStrafe.mc.field_71439_g.field_70702_br = 0.0f;
            } else if (BetterStrafe.mc.field_71439_g.field_191988_bg < 0.0f) {
                if (BetterStrafe.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f) {
                    yaw += BetterStrafe.mc.field_71439_g.field_71158_b.field_78902_a > 0.0f ? 45.0f : -45.0f;
                }
                this.forward = -1;
                BetterStrafe.mc.field_71439_g.field_191988_bg = -1.0f;
                BetterStrafe.mc.field_71439_g.field_70702_br = 0.0f;
            }
            if (BetterStrafe.mc.field_71439_g.field_70122_E) {
                BetterStrafe.mc.field_71439_g.func_70637_d(false);
                if (this.waitCounter < 1) {
                    ++this.waitCounter;
                    return;
                }
                this.waitCounter = 0;
                float f = (float)Math.toRadians(yaw);
                BetterStrafe.mc.field_71439_g.field_70181_x = 0.4;
                EntityPlayerSP player = BetterStrafe.mc.field_71439_g;
                player.field_70159_w -= (double)(MathHelper.func_76126_a((float)f) * 0.195f) * (double)this.forward;
                EntityPlayerSP player2 = BetterStrafe.mc.field_71439_g;
                player2.field_70179_y += (double)(MathHelper.func_76134_b((float)f) * 0.195f) * (double)this.forward;
            }
        } else {
            double speed;
            if (this.waitCounter < 1) {
                ++this.waitCounter;
                return;
            }
            this.waitCounter = 0;
            double currentSpeed = Math.sqrt(BetterStrafe.mc.field_71439_g.field_70159_w * BetterStrafe.mc.field_71439_g.field_70159_w + BetterStrafe.mc.field_71439_g.field_70179_y * BetterStrafe.mc.field_71439_g.field_70179_y);
            double d = speed = boost ? 1.0034 : 1.001;
            if (BetterStrafe.mc.field_71439_g.field_70181_x < 0.0) {
                speed = 1.0;
            }
            double yaw = 0.0;
            double direction = Math.toRadians(yaw);
            BetterStrafe.mc.field_71439_g.field_70159_w = -Math.sin(direction) * speed * currentSpeed * (double)this.forward;
            BetterStrafe.mc.field_71439_g.field_70179_y = Math.cos(direction) * speed * currentSpeed * (double)this.forward;
        }
    }
}
