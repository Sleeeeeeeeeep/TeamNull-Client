package me.travis.wurstplus.wurstplustwo.hacks.movement;


import me.travis.wurstplus.Wurstplus;
import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventGUIScreen;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraftforge.client.settings.IKeyConflictContext;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.input.Keyboard;
import java.util.function.Predicate;
import net.minecraft.client.gui.GuiChat;
import me.zero.alpine.fork.listener.EventHandler;
import me.zero.alpine.fork.listener.Listener;
import net.minecraft.client.settings.KeyBinding;



public class InventoryMove extends WurstplusHack {


	private static final KeyBinding[] KEYS;
	@EventHandler
	private final Listener<WurstplusEventGUIScreen> state_gui;


    public InventoryMove() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);
        this.name = "Inventory Move";
        this.tag = "InventoryMove";
        this.description = "move in guis";


		this.state_gui = new Listener<WurstplusEventGUIScreen>(event -> {
			if (mc.field_71439_g == null && mc.field_71441_e == null) {
				return;
			}
			else if (event.get_guiscreen() instanceof GuiChat || event.get_guiscreen() == null) {
				return;
			}
			else {
				this.walk();
				return;
			}
        
    });
	}

		@Override
		public void update() {
			if (mc.field_71439_g == null && mc.field_71441_e == null) {
				return;
			}
			if (mc.field_71462_r instanceof GuiChat || mc.field_71462_r == null) {
				return;
			}
			this.walk();
		}

		public void walk() {
			for (final KeyBinding key_binding : KEYS) {
				if (Keyboard.isKeyDown(key_binding.func_151463_i())) {
					if (key_binding.getKeyConflictContext() != KeyConflictContext.UNIVERSAL) {
						key_binding.setKeyConflictContext((IKeyConflictContext)KeyConflictContext.UNIVERSAL);
					}
					KeyBinding.func_74510_a(key_binding.func_151463_i(), true);
				}
				else {
					KeyBinding.func_74510_a(key_binding.func_151463_i(), false);
				}
			}
		}

		static {
			KEYS = new KeyBinding[] { mc.field_71474_y.field_74351_w, mc.field_71474_y.field_74366_z, mc.field_71474_y.field_74368_y, mc.field_71474_y.field_74370_x, mc.field_71474_y.field_74314_A, mc.field_71474_y.field_151444_V };
		}
	}