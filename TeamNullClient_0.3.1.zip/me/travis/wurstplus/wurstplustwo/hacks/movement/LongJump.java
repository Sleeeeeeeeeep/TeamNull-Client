package me.travis.wurstplus.wurstplustwo.hacks.movement;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(value={Side.CLIENT})
public class LongJump
        extends WurstplusHack {
    WurstplusSetting speed = this.create("Speed", "LGSpeed", 30.0, 1.0, 100.0);
    WurstplusSetting packet = this.create("Packet", "LGPacket", false);
    WurstplusSetting toggle = this.create("Toggle", "LGToggle", false);
    private static boolean jumped = false;
    private static boolean boostable = false;

    public LongJump() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);
        this.name = "Long Jump";
        this.tag = "LongJump";
        this.description = "jumps longer";
    }

    @Override
    public void update() {
        if (LongJump.mc.field_71439_g == null || LongJump.mc.field_71441_e == null) {
            return;
        }
        if (jumped) {
            if (LongJump.mc.field_71439_g.field_70122_E || LongJump.mc.field_71439_g.field_71075_bZ.field_75100_b) {
                jumped = false;
                LongJump.mc.field_71439_g.field_70159_w = 0.0;
                LongJump.mc.field_71439_g.field_70179_y = 0.0;
                if (this.packet.get_value(true)) {
                    LongJump.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(LongJump.mc.field_71439_g.field_70165_t, LongJump.mc.field_71439_g.field_70163_u, LongJump.mc.field_71439_g.field_70161_v, LongJump.mc.field_71439_g.field_70122_E));
                    LongJump.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(LongJump.mc.field_71439_g.field_70165_t + LongJump.mc.field_71439_g.field_70159_w, 0.0, LongJump.mc.field_71439_g.field_70161_v + LongJump.mc.field_71439_g.field_70179_y, LongJump.mc.field_71439_g.field_70122_E));
                }
                if (this.toggle.get_value(true)) {
                    this.toggle();
                }
                return;
            }
            if (LongJump.mc.field_71439_g.field_71158_b.field_192832_b == 0.0f && LongJump.mc.field_71439_g.field_71158_b.field_78902_a == 0.0f) {
                return;
            }
            double yaw = this.getDirection();
            LongJump.mc.field_71439_g.field_70159_w = -Math.sin(yaw) * (double)((float)Math.sqrt(LongJump.mc.field_71439_g.field_70159_w * LongJump.mc.field_71439_g.field_70159_w + LongJump.mc.field_71439_g.field_70179_y * LongJump.mc.field_71439_g.field_70179_y) * (boostable ? (float)this.speed.get_value(0) / 10.0f : 1.0f));
            LongJump.mc.field_71439_g.field_70179_y = Math.cos(yaw) * (double)((float)Math.sqrt(LongJump.mc.field_71439_g.field_70159_w * LongJump.mc.field_71439_g.field_70159_w + LongJump.mc.field_71439_g.field_70179_y * LongJump.mc.field_71439_g.field_70179_y) * (boostable ? (float)this.speed.get_value(0) / 10.0f : 1.0f));
            boostable = false;
            if (this.toggle.get_value(true)) {
                this.toggle();
            }
        }
        if (LongJump.mc.field_71439_g.field_71158_b.field_192832_b == 0.0f && LongJump.mc.field_71439_g.field_71158_b.field_78902_a == 0.0f && jumped) {
            LongJump.mc.field_71439_g.field_70159_w = 0.0;
            LongJump.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @SubscribeEvent
    public static void onJump(LivingEvent.LivingJumpEvent event) {
        if (LongJump.mc.field_71439_g != null && LongJump.mc.field_71441_e != null && event.getEntity() == LongJump.mc.field_71439_g && (LongJump.mc.field_71439_g.field_71158_b.field_192832_b != 0.0f || LongJump.mc.field_71439_g.field_71158_b.field_78902_a != 0.0f)) {
            jumped = true;
            boostable = true;
        }
    }

    private double getDirection() {
        float rotationYaw = LongJump.mc.field_71439_g.field_70177_z;
        if (LongJump.mc.field_71439_g.field_191988_bg < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (LongJump.mc.field_71439_g.field_191988_bg < 0.0f) {
            forward = -0.5f;
        } else if (LongJump.mc.field_71439_g.field_191988_bg > 0.0f) {
            forward = 0.5f;
        }
        if (LongJump.mc.field_71439_g.field_70702_br > 0.0f) {
            rotationYaw -= 90.0f * forward;
        }
        if (LongJump.mc.field_71439_g.field_70702_br < 0.0f) {
            rotationYaw += 90.0f * forward;
        }
        return Math.toRadians(rotationYaw);
    }
}