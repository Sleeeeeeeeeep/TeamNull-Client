package me.travis.wurstplus.wurstplustwo.hacks.movement;

import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.network.play.client.CPacketPlayer;

public class AirJump
        extends WurstplusHack {
    public AirJump() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);
        this.name = "Air Jump";
        this.tag = "AirJump";
        this.description = "Maybe usefull";
    }

    WurstplusSetting packet = create("Packet", "AirJumpPacket", true);


    @Override
    public void update() {
        if( packet.get_value(false)){
            mc.field_71439_g.field_70122_E = true;
    }
            else if(packet.get_value(true)) {
            mc.field_71439_g.field_70122_E = true;
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.41999998688698D, mc.field_71439_g.field_70161_v, true));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.7531999805211997D, mc.field_71439_g.field_70161_v, true));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.00133597911214D, mc.field_71439_g.field_70161_v, true));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.16610926093821D, mc.field_71439_g.field_70161_v, true));
            }
        }
}



