package me.travis.wurstplus.wurstplustwo.hacks.movement;

import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;

public class WurstplusSprint extends WurstplusHack {
    
    public WurstplusSprint() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);

		this.name        = "Sprint";
		this.tag         = "Sprint";
		this.description = "ZOOOOOOOOM";
    }

    WurstplusSetting rage = create("Rage", "SprintRage", true);

    @Override
	public void update() {

    	if (mc.field_71439_g == null) return;

    	if (rage.get_value(true) && (mc.field_71439_g.field_191988_bg != 0 || mc.field_71439_g.field_70702_br != 0)) {
			mc.field_71439_g.func_70031_b(true);
		} else mc.field_71439_g.func_70031_b(mc.field_71439_g.field_191988_bg > 0 || mc.field_71439_g.field_70702_br > 0);
		
	}


}