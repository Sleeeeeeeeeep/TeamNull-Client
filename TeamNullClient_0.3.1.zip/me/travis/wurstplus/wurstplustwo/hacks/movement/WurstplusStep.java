package me.travis.wurstplus.wurstplustwo.hacks.movement;

import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.AxisAlignedBB;

public class WurstplusStep extends WurstplusHack {
    
    public WurstplusStep() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);

		this.name        = "Step";
		this.tag         = "Step";
		this.description = "Move up block big";
    }

    @Override
    public void update() {

        if (!mc.field_71439_g.field_70123_F) return;
        if (!mc.field_71439_g.field_70122_E || mc.field_71439_g.func_70617_f_() || mc.field_71439_g.func_70090_H() || mc.field_71439_g.func_180799_ab() || mc.field_71439_g.field_71158_b.field_78901_c || mc.field_71439_g.field_70145_X) return;
        if (mc.field_71439_g.field_191988_bg == 0 && mc.field_71439_g.field_70702_br == 0) return;

        final double n = get_n_normal();

        

            if (n < 0 || n > 2) return;

            if (n == 2.0) {
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.42, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.78, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.63, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.51, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.9, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.21, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.45, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.43, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.func_70107_b(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 2.0, mc.field_71439_g.field_70161_v);
            }
            if (n == 1.5) {
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.41999998688698, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.7531999805212, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.00133597911214, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.16610926093821, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.24918707874468, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.1707870772188, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.func_70107_b(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.0, mc.field_71439_g.field_70161_v);
            }
            if (n == 1.0) {
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.41999998688698, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.7531999805212, mc.field_71439_g.field_70161_v, mc.field_71439_g.field_70122_E));
                mc.field_71439_g.func_70107_b(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.0, mc.field_71439_g.field_70161_v);
            }

        }

    public double get_n_normal() {

        mc.field_71439_g.field_70138_W = 0.5f;

        double max_y = -1;

        final AxisAlignedBB grow = mc.field_71439_g.func_174813_aQ().func_72317_d(0, 0.05, 0).func_186662_g(0.05);

        if (!mc.field_71441_e.func_184144_a(mc.field_71439_g, grow.func_72317_d(0, 2, 0)).isEmpty()) return 100;

        for (final AxisAlignedBB aabb : mc.field_71441_e.func_184144_a(mc.field_71439_g, grow)) {

            if (aabb.field_72337_e > max_y) {
                max_y = aabb.field_72337_e;
            }

        }

        return max_y - mc.field_71439_g.field_70163_u;

    }
}    