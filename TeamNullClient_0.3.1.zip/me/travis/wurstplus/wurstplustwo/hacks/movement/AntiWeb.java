package me.travis.wurstplus.wurstplustwo.hacks.movement;

import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.network.play.client.CPacketPlayer;

public class AntiWeb
        extends WurstplusHack {
    public AntiWeb() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);
        this.name = "Anti Web";
        this.tag = "AntiWeb";
        this.description = "no te bajan la velocidad las cobwebs";
    }


    WurstplusSetting vertical = create("Vertical Speed", "VerticalSpeed", 2.0, 0.0, 100.0);
    WurstplusSetting horizontal = create("Horizontal Speed", "HorizontalSpeed", 2.0, 0.0, 100.0);

    @Override
    public void update() {

        if(mc.field_71439_g.field_70134_J) {

            mc.field_71439_g.field_70159_w *= horizontal.get_value(0);
            mc.field_71439_g.field_70181_x *= vertical.get_value(0);
            mc.field_71439_g.field_70179_y *= horizontal.get_value(0);

        }

        }
}



