package me.travis.wurstplus.wurstplustwo.hacks.movement;

import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventMotionUpdate;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.zero.alpine.fork.listener.EventHandler;
import me.zero.alpine.fork.listener.Listener;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;

public class WurstPlusAnchor extends WurstplusHack {

    // Written by NathanW, thanks to my friend Ian for some hole shit.

    public WurstPlusAnchor() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);

        this.name        = "Anchor";
        this.tag         = "WurstPlusAnchor";
        this.description = "Stops all movement if player is above a hole";
    }

    WurstplusSetting Pitch = create("Pitch", "AnchorPitch", 60, 0, 90);
    WurstplusSetting Pull = create("Pull", "AnchorPull", true);

    private final ArrayList<BlockPos> holes = new ArrayList<BlockPos>();
    int holeblocks;


    public static boolean AnchorING;
    public boolean isBlockHole(BlockPos blockpos) {
        holeblocks = 0;
        if (mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 3, 0)).func_177230_c() == Blocks.field_150350_a) ++holeblocks;

        if (mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 2, 0)).func_177230_c() == Blocks.field_150350_a) ++holeblocks;

        if (mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 1, 0)).func_177230_c() == Blocks.field_150350_a) ++holeblocks;

        if (mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 0, 0)).func_177230_c() == Blocks.field_150350_a) ++holeblocks;

        if (mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150343_Z || mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, -1, 0)).func_177230_c() == Blocks.field_150357_h) ++holeblocks;

        if (mc.field_71441_e.func_180495_p(blockpos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150343_Z ||mc.field_71441_e.func_180495_p(blockpos.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150357_h) ++holeblocks;

        if (mc.field_71441_e.func_180495_p(blockpos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150343_Z ||mc.field_71441_e.func_180495_p(blockpos.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150357_h) ++holeblocks;

        if (mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150343_Z ||mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150357_h) ++holeblocks;

        if (mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150343_Z ||mc.field_71441_e.func_180495_p(blockpos.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150357_h) ++holeblocks;

        if (holeblocks >= 9) return true;
        else return false;
    }
    private Vec3d Center = Vec3d.field_186680_a;

    public Vec3d GetCenter(double posX, double posY, double posZ) {
        double x = Math.floor(posX) + 0.5D;
        double y = Math.floor(posY);
        double z = Math.floor(posZ) + 0.5D ;

        return new Vec3d(x, y, z);
    }

    @EventHandler
    private Listener<WurstplusEventMotionUpdate> OnClientTick = new Listener<>(event -> {
        if (mc.field_71439_g.field_70125_A >= Pitch.get_value(60)) {

            if (isBlockHole(getPlayerPos().func_177979_c(1)) || isBlockHole(getPlayerPos().func_177979_c(2)) ||
                    isBlockHole(getPlayerPos().func_177979_c(3)) || isBlockHole(getPlayerPos().func_177979_c(4))) {
                AnchorING = true;

                if (!Pull.get_value(true)) {
                    mc.field_71439_g.field_70159_w = 0.0;
                    mc.field_71439_g.field_70179_y = 0.0;
                } else {
                    Center = GetCenter(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
                    double XDiff = Math.abs(Center.field_72450_a - mc.field_71439_g.field_70165_t);
                    double ZDiff = Math.abs(Center.field_72449_c - mc.field_71439_g.field_70161_v);

                    if (XDiff <= 0.1 && ZDiff <= 0.1) {
                        Center = Vec3d.field_186680_a;
                    }
                    else {
                        double MotionX = Center.field_72450_a-mc.field_71439_g.field_70165_t;
                        double MotionZ = Center.field_72449_c-mc.field_71439_g.field_70161_v;

                        mc.field_71439_g.field_70159_w = MotionX/2;
                        mc.field_71439_g.field_70179_y = MotionZ/2;
                    }
                }
            } else AnchorING = false;
        }
    });

    public void onDisable() {
        AnchorING = false;
        holeblocks = 0;
    }

    public BlockPos getPlayerPos() {
        return new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u), Math.floor(mc.field_71439_g.field_70161_v));
    }

}