package me.travis.wurstplus.wurstplustwo.hacks.chat;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventPacket;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.util.WurstplusFriendUtil;
import me.travis.wurstplus.wurstplustwo.util.WurstplusMessageUtil;
import me.zero.alpine.fork.listener.EventHandler;
import me.zero.alpine.fork.listener.Listener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityStatus;

import java.util.HashMap;


public class WurstplusTotempop extends WurstplusHack {
    
    public WurstplusTotempop() {
		super(WurstplusCategory.WURSTPLUS_CHAT);

		this.name        = "Totem Pop Counter";
		this.tag         = "TotemPopCounter";
		this.description = "dude idk wurst+ is just outdated";
    }

    public static final HashMap<String, Integer> totem_pop_counter = new HashMap<String, Integer>();
    
    public static ChatFormatting red = ChatFormatting.RED;
    public static ChatFormatting green = ChatFormatting.GREEN;
    public static ChatFormatting gold = ChatFormatting.GOLD;
    public static ChatFormatting grey = ChatFormatting.GRAY;
    public static ChatFormatting bold = ChatFormatting.BOLD;
    public static ChatFormatting reset = ChatFormatting.RESET;

    @EventHandler
    private final Listener<WurstplusEventPacket.ReceivePacket> packet_event = new Listener<>(event -> {

        if (event.get_packet() instanceof SPacketEntityStatus) {

            SPacketEntityStatus packet = (SPacketEntityStatus) event.get_packet();

            if (packet.func_149160_c() == 35) {

                Entity entity = packet.func_149161_a(mc.field_71441_e);

                int count = 1;

                if (totem_pop_counter.containsKey(entity.func_70005_c_())) {
                    count = totem_pop_counter.get(entity.func_70005_c_());
                    totem_pop_counter.put(entity.func_70005_c_(), ++count);
                } else {
                    totem_pop_counter.put(entity.func_70005_c_(), count);
                }

                if (entity == mc.field_71439_g) return;

                if (WurstplusFriendUtil.isFriend(entity.func_70005_c_())) {
                    WurstplusMessageUtil.send_client_message( red + "" + bold + " TotemPop " + reset + grey + " > " + reset + "dude, " + bold + green + entity.func_70005_c_() + reset + " has popped " + bold + count + reset + " totems. you should go help them");
                } else {
                    WurstplusMessageUtil.send_client_message( red + "" + bold + " TotemPop " + reset + grey + " > " + reset + "dude, " + bold + red + entity.func_70005_c_() + reset + " has popped " + bold + count + reset + " totems. what a loser");
                }

            }

        }

    });

    @Override
	public void update() {
        
        for (EntityPlayer player : mc.field_71441_e.field_73010_i) {

            if (!totem_pop_counter.containsKey(player.func_70005_c_())) continue;

            if (player.field_70128_L || player.func_110143_aJ() <= 0) {

                int count = totem_pop_counter.get(player.func_70005_c_());

                totem_pop_counter.remove(player.func_70005_c_());

                if (player == mc.field_71439_g) continue;

                if (WurstplusFriendUtil.isFriend(player.func_70005_c_())) {
                    WurstplusMessageUtil.send_client_message( red + "" + bold + " TotemPop " + reset + grey + " > " + reset + "dude, " + bold + green + player.func_70005_c_() + reset + " just fucking DIED after popping " + bold + count + reset + " totems. RIP :pray:");
                } else {
                    WurstplusMessageUtil.send_client_message( red + "" + bold + " TotemPop " + reset + grey + " > " + reset + "dude, " + bold + red + player.func_70005_c_() + reset + " just fucking DIED after popping " + bold + count + reset + " totems");
                }

            }

        }

	}

}