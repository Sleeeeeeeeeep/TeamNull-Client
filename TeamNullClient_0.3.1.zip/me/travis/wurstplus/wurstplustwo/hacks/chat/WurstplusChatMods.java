package me.travis.wurstplus.wurstplustwo.hacks.chat;


import com.mojang.realmsclient.gui.ChatFormatting;

import me.travis.wurstplus.Wurstplus;
import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventPacket;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.travis.wurstplus.wurstplustwo.manager.WurstplusCommandManager;
import me.travis.wurstplus.wurstplustwo.util.WurstplusMessageUtil;
import me.zero.alpine.fork.listener.EventHandler;
import me.zero.alpine.fork.listener.Listener;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.TextComponentString;
import scala.util.Random;

import java.text.SimpleDateFormat;
import java.util.Date;

public final class WurstplusChatMods extends WurstplusHack {
    
    public WurstplusChatMods() {
        super(WurstplusCategory.WURSTPLUS_CHAT);

        this.name = "Chat Modifications";
        this.tag = "ChatModifications";
        this.description = "this breaks things";
    }

    // GuiNewChat nc = new GuiNewChat(mc);

    WurstplusSetting timestamps = create("Timestamps", "ChatModsTimeStamps", true);
    WurstplusSetting dateformat = create("Date Format", "ChatModsDateFormat", "24HR", combobox("24HR", "12HR"));
    WurstplusSetting name_highlight = create("Name Highlight", "ChatModsNameHighlight", true);
    WurstplusSetting prefix = create("ChatPrefix", "ChatPrefixModule", true);
    WurstplusSetting prefix_mode = create("Prefix", "CPrefix", ">", combobox(">","`", "#", "&", "%", "$", "*", ","));
	WurstplusSetting space = create("Space", "CPrefixSpace", true);
    WurstplusSetting suffix = create("ChatSuffix", "ChatSuffixModule", true);
    WurstplusSetting suffix_mode = create("Suffix", "CSuffix", "Default", combobox("Default", "Random"));
    WurstplusSetting ignore = create("Ignore", "ChatSuffixIgnore", true);
	WurstplusSetting clear_chatbox = create("Clear Chatbox", "ClearChatbox", false);

    int delay_count = 0;

    @EventHandler
    private Listener<WurstplusEventPacket.ReceivePacket> PacketEvent = new Listener<>(event -> {

        if (event.get_packet() instanceof SPacketChat) {

            final SPacketChat packet = (SPacketChat) event.get_packet();

            if (packet.func_148915_c() instanceof TextComponentString) {
                final TextComponentString component = (TextComponentString) packet.func_148915_c();

            if (timestamps.get_value(true)) {

                    String date = "";

                    if (dateformat.in("12HR")) {
                        date = new SimpleDateFormat("h:mm a").format(new Date());
                    }

                    if (dateformat.in("24HR")) {
                        date = new SimpleDateFormat("k:mm").format(new Date());

                    }

                    component.field_150267_b = "\2477[" + date + "]\247r " + component.field_150267_b;

                }

                String text = component.func_150254_d();

                if (text.contains("combat for")) return;

                if (name_highlight.get_value(true) && mc.field_71439_g != null) {

                    if (text.toLowerCase().contains(mc.field_71439_g.func_70005_c_().toLowerCase())) {

                        text = text.replaceAll("(?i)" + mc.field_71439_g.func_70005_c_(), ChatFormatting.GOLD + mc.field_71439_g.func_70005_c_() + ChatFormatting.RESET);

                    }

                }

                event.cancel();

                WurstplusMessageUtil.client_message(text);

            }
        }
    });
    // prefics
    @EventHandler
    private Listener<WurstplusEventPacket.SendPacket> listener = new Listener<>(event -> {
        if(event.get_packet() instanceof CPacketChatMessage){
            if(((CPacketChatMessage) event.get_packet()).func_149439_c().startsWith("/") || ((CPacketChatMessage) event.get_packet()).func_149439_c().startsWith(WurstplusCommandManager.get_prefix())) return;
            String message = ((CPacketChatMessage) event.get_packet()).func_149439_c();
            String prefix_msg = "";
            String sp = "";
            
            
            if(this.prefix_mode.in(">")) prefix_msg = ">";
            if(this.prefix_mode.in("`")) prefix_msg = "`";
            if(this.prefix_mode.in("#")) prefix_msg = "#";
            if(this.prefix_mode.in("&")) prefix_msg = "&";
            if(this.prefix_mode.in("%")) prefix_msg = "%";
            if(this.prefix_mode.in("$")) prefix_msg = "$";
            if(this.prefix_mode.in("*")) prefix_msg = "*";
            if(this.prefix_mode.in(",")) prefix_msg = ",";
            
            if(space.get_value(true)) sp = " "; 
            
        else 

        sp = "";
        
        
            if (prefix.get_value(true)){
                String s = prefix_msg + sp + message;
            if(s.length() > 255) return;
            ((CPacketChatMessage) event.get_packet()).field_149440_a = s;
            }
            
        }
    });
    boolean accept_suffix;
	boolean suffix_default;
	boolean suffix_random;

	StringBuilder suffics;

	String[] random_client_name = {
		"huzuniplus",
		"pouware",
		"sleeeeeeeeeep",
		"ratted",
		"skided",
		""
	};

	String[] random_client_finish = {
		" sex",
		" god",
		" very epic",
		" +",
		" | discord.gg/JsEwSu5G",
		" | discord.gg/pou",
		" | proud imrcfag"
	};

	@EventHandler
	private Listener<WurstplusEventPacket.SendPacket> listener2 = new Listener<>(event -> {
		// If not be the CPacketChatMessage return.
		if (!(event.get_packet() instanceof CPacketChatMessage)) {
			return;
		}

		// Start event suffix.
		accept_suffix = true;

		// Get value.
		boolean ignore_prefix = ignore.get_value(true);

		String message = ((CPacketChatMessage) event.get_packet()).func_149439_c();

		// If is with some caracther.
		if (message.startsWith("/")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith("\\") && ignore_prefix) accept_suffix = false;
		if (message.startsWith("!")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith(":")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith(";")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith(".")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith(",")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith("@")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith("&")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith("*")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith("$")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith("#")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith("(")  && ignore_prefix) accept_suffix = false;
		if (message.startsWith(")")  && ignore_prefix) accept_suffix = false;

		// Compare the values type.
		if (suffix_mode.in("Default")) {
			suffix_default = true;
			suffix_random  = false;
		}

		if (suffix_mode.in("Random")) {
			suffix_default = false;
			suffix_random  = true;
		}

		// If accept.
		if (accept_suffix) {
			if (suffix_default) {
				// Just default.
				message += Wurstplus.WURSTPLUS_SIGN + convert_base(" | " + Wurstplus.TEAMNULLCLIENT);
			}

			if (suffix_random) {
				// Create first the string builder.
				StringBuilder suffix_with_randoms = new StringBuilder();

				// Convert the base using the TravisFont.
				suffix_with_randoms.append(convert_base(random_string(random_client_name)));
				suffix_with_randoms.append(convert_base(random_string(random_client_finish)));

				message += Wurstplus.WURSTPLUS_SIGN + suffix_with_randoms.toString(); 
			}

			// If message 256 string length substring.
			if (message.length() >= 256) {
				message.substring(0, 256);
			}
		}

		// Send the message.
		((CPacketChatMessage) event.get_packet()).field_149440_a = message;
	});

	// Get the random values string.
	public String random_string(String[] list) {
		return list[new Random().nextInt(list.length)];
	}

	// Convert the base using the TravisFont.
	public String convert_base(String base) {
		return Wurstplus.smoth(base);
	}

	@Override
	public String array_detail() {
		// Update the detail.
		return this.suffix_mode.get_current_value();
	}
}