package me.travis.wurstplus.wurstplustwo.hacks.chat;

import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventPacket;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import me.zero.alpine.fork.listener.EventHandler;
import me.zero.alpine.fork.listener.Listener;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class WurstplusAntiRacist extends WurstplusHack {

    /*
     *    Updated by NathanW because we need to end racism on anarchy servers
     */

    public WurstplusAntiRacist() {
        super(WurstplusCategory.WURSTPLUS_CHAT);

        this.name = "TFB Spammer";
        this.tag = "TFBSpammer";
        this.description = "i love black squares (circles on the other hand...)";
    }

    WurstplusSetting delay = create("Delay", "AntiRacistDelay", 10, 0, 100);
    WurstplusSetting anti_nword = create("AntiNword", "AntiRacismAntiNword", true);
    WurstplusSetting chanter = create("Chanter", "AntiRacismChanter", false);

    List<String> chants = new ArrayList<>();

    Random r = new Random();
    int tick_delay;

    @Override
    protected void enable() {
        tick_delay = 0;

        chants.add("TheFuckBoys on top! https://discord.gg/pou");
        chants.add("Pou owns u https://discord.gg/pou");
        chants.add("TheFuckBoys Owning 00 https://discord.gg/pou");
    }

    String[] random_correction = {
    };


    CharSequence nigger = "nigger";
    CharSequence nigga = "nigga";

    @Override
    public void update() {

        if(chanter.get_value(true)) {

            tick_delay++;

            if (tick_delay < delay.get_value(1) * 10) return;

            String s = chants.get(r.nextInt(chants.size()));
            String name = get_random_name();

            if (name.equals(mc.field_71439_g.func_70005_c_())) return;

            mc.field_71439_g.func_71165_d(s.replace("<player>", name));
            tick_delay = 0;

            }
        }

    public String get_random_name() {

            List<EntityPlayer> players = mc.field_71441_e.field_73010_i;
            return players.get(r.nextInt(players.size())).func_70005_c_();
        }


    public String random_string(String[] list) {
        return list[r.nextInt(list.length)];
    }

    // Anti n-word

    @EventHandler
    private Listener<WurstplusEventPacket.SendPacket> listener = new Listener<>(event -> {

        if (!(event.get_packet() instanceof CPacketChatMessage)) {
            return;
        }

        if(anti_nword.get_value(true)) {

            String message = ((CPacketChatMessage) event.get_packet()).func_149439_c().toLowerCase();

            if (message.contains(nigger) || message.contains(nigga)) {

                String x = Integer.toString((int) (mc.field_71439_g.field_70165_t));
                String z = Integer.toString((int) (mc.field_71439_g.field_70161_v));

                String coords = x + " " + z;

                message = (random_string(random_correction));
                mc.field_71439_g.field_71174_a.func_147297_a(new CPacketChatMessage("Hi, im at " + coords + ", come teach me a lesson about racism"));

            }

            ((CPacketChatMessage) event.get_packet()).field_149440_a = message;
        }
    });


}
