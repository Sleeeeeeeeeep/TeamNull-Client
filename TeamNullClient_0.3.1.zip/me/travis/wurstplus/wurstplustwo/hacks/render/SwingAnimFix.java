package me.travis.wurstplus.wurstplustwo.hacks.render;

import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;


public class SwingAnimFix extends WurstplusHack {
	
	public SwingAnimFix() {
		

        super(WurstplusCategory.WURSTPLUS_RENDER);

        this.name = "Swing Anim Fix";
        this.tag = "SwingAnimFix";
        this.description = "pasted from zori lol";
    }
	@Override
    public void update() {
        if (mc.field_71439_g == null) {
            return;
        }
        if (mc.field_71460_t.field_78516_c.field_187469_f < 1.0f) {
            mc.field_71460_t.field_78516_c.field_187469_f = 1.0f;
        }
        if (mc.field_71460_t.field_78516_c.field_187467_d != mc.field_71439_g.func_184614_ca()) {
            mc.field_71460_t.field_78516_c.field_187467_d = mc.field_71439_g.func_184614_ca();
        }
    }
}


