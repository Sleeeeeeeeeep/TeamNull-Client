package me.travis.wurstplus.wurstplustwo.hacks.render;

import me.travis.wurstplus.Wurstplus;
import me.travis.wurstplus.wurstplustwo.event.events.WurstplusEventRender;
import me.travis.wurstplus.wurstplustwo.guiscreen.settings.WurstplusSetting;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusCategory;
import me.travis.wurstplus.wurstplustwo.hacks.WurstplusHack;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

public class WurstplusVoidESP extends WurstplusHack {

    public WurstplusVoidESP() {
        super(WurstplusCategory.WURSTPLUS_RENDER);

        this.name        = "Void ESP";
        this.tag         = "VoidESP";
        this.description = "OH FUCK A DEEP HOLE";
    }

    WurstplusSetting void_radius = create("Range", "VoidESPRange", 6, 1, 10);

    public final List<BlockPos> void_blocks = new ArrayList<>();

    private final ICamera camera = new Frustum();

    @Override
    public void update() {
        
        if (mc.field_71439_g == null) return;

        void_blocks.clear();

        final Vec3i player_pos = new Vec3i(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);

        for (int x = player_pos.func_177958_n() - void_radius.get_value(1); x < player_pos.func_177958_n() + void_radius.get_value(1); x++) {
            for (int z = player_pos.func_177952_p() - void_radius.get_value(1); z < player_pos.func_177952_p() + void_radius.get_value(1); z++) {
                for (int y = player_pos.func_177956_o() + void_radius.get_value(1); y > player_pos.func_177956_o() - void_radius.get_value(1); y--) {
                    final BlockPos blockPos = new BlockPos(x, y, z);

                    if (is_void_hole(blockPos))
                        void_blocks.add(blockPos);
                }
            }
        }

    }

    public boolean is_void_hole(BlockPos blockPos) {
        if (blockPos.func_177956_o() != 0)
            return false;

        if (mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150350_a)
            return false;

        return true;

    }

    @Override
	public void render(WurstplusEventRender event) {

        int r = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorR").get_value(1);
        int g = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorG").get_value(1);
        int b = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorB").get_value(1);

        new ArrayList<>(void_blocks).forEach(pos -> {

            final AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - mc.func_175598_ae().field_78730_l, pos.func_177956_o() - mc.func_175598_ae().field_78731_m,
                    pos.func_177952_p() - mc.func_175598_ae().field_78728_n, pos.func_177958_n() + 1 - mc.func_175598_ae().field_78730_l, pos.func_177956_o() + 1 - mc.func_175598_ae().field_78731_m,
                    pos.func_177952_p() + 1 - mc.func_175598_ae().field_78728_n);

            camera.func_78547_a(mc.func_175606_aa().field_70165_t, mc.func_175606_aa().field_70163_u, mc.func_175606_aa().field_70161_v);

            if (camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + mc.func_175598_ae().field_78730_l, bb.field_72338_b + mc.func_175598_ae().field_78731_m, bb.field_72339_c + mc.func_175598_ae().field_78728_n,
                    bb.field_72336_d + mc.func_175598_ae().field_78730_l, bb.field_72337_e + mc.func_175598_ae().field_78731_m, bb.field_72334_f + mc.func_175598_ae().field_78728_n)))
            {
                GlStateManager.func_179094_E();
                GlStateManager.func_179147_l();
                GlStateManager.func_179097_i();
                GlStateManager.func_179120_a(770, 771, 0, 1);
                GlStateManager.func_179090_x();
                GlStateManager.func_179132_a(false);
                GL11.glEnable(GL11.GL_LINE_SMOOTH);
                GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
                GL11.glLineWidth(1.5f);

                RenderGlobal.func_189694_a(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb.field_72337_e, bb.field_72334_f, 255, 20, 30, 0.50f);
                RenderGlobal.func_189695_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb.field_72337_e, bb.field_72334_f, 255, 20, 30, 0.22f);

                GL11.glDisable(GL11.GL_LINE_SMOOTH);
                GlStateManager.func_179132_a(true);
                GlStateManager.func_179126_j();
                GlStateManager.func_179098_w();
                GlStateManager.func_179084_k();
                GlStateManager.func_179121_F();
            }
        });

    }
    
}