package me.travis.turok.draw;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.BlockPos;

import java.util.Arrays;

import static org.lwjgl.opengl.GL11.*;

/**
* @author 086
*
* Update by me.
* 08/04/20.
*
*/
public class RenderHelp extends Tessellator {
    public static RenderHelp INSTANCE = new RenderHelp();

    public RenderHelp() {
        super(0x200000);
    }

    public static void prepare(String mode_requested) {
    	int mode = 0;

    	if (mode_requested.equalsIgnoreCase("quads")) {
    		mode = GL_QUADS;
    	} else if (mode_requested.equalsIgnoreCase("lines")) {
    		mode = GL_LINES;
    	}

        prepare_gl();
        begin(mode);
    }

    public static void prepare_gl() {
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.func_187441_d(1.5F);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179140_f();
        GlStateManager.func_179129_p();
        GlStateManager.func_179141_d();
        GlStateManager.func_179124_c(1, 1, 1);
    }

    public static void begin(int mode) {
        INSTANCE.func_178180_c().func_181668_a(mode, DefaultVertexFormats.field_181706_f);
    }

    public static void release() {
        render();
        release_gl();
    }

    public static void render() {
        INSTANCE.func_78381_a();
    }

    public static void release_gl() {
        GlStateManager.func_179089_o();
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179147_l();
        GlStateManager.func_179126_j();
    }

    public static void draw_cube(BlockPos blockPos, int argb, String sides) {
        final int a = (argb >>> 24) & 0xFF;
        final int r = (argb >>> 16) & 0xFF;
        final int g = (argb >>> 8) & 0xFF;
        final int b = argb & 0xFF;
        draw_cube(blockPos, r, g, b, a, sides);
    }

    public static void draw_cube(float x, float y, float z, int argb, String sides) {
        final int a = (argb >>> 24) & 0xFF;
        final int r = (argb >>> 16) & 0xFF;
        final int g = (argb >>> 8) & 0xFF;
        final int b = argb & 0xFF;
        draw_cube(INSTANCE.func_178180_c(), x, y, z, 1, 1, 1, r, g, b, a, sides);
    }

    public static void draw_cube(BlockPos blockPos, int r, int g, int b, int a, String sides) {
        draw_cube(INSTANCE.func_178180_c(), blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), 1, 1, 1, r, g, b, a, sides);
    }

    public static void draw_cube_line(BlockPos blockPos, int argb, String sides) {
        final int a = (argb >>> 24) & 0xFF;
        final int r = (argb >>> 16) & 0xFF;
        final int g = (argb >>> 8) & 0xFF;
        final int b = argb & 0xFF;
        draw_cube_line(blockPos, r, g, b, a, sides);
    }

    public static void draw_cube_line(float x, float y, float z, int argb, String sides) {
        final int a = (argb >>> 24) & 0xFF;
        final int r = (argb >>> 16) & 0xFF;
        final int g = (argb >>> 8) & 0xFF;
        final int b = argb & 0xFF;
        draw_cube_line(INSTANCE.func_178180_c(), x, y, z, 1, 1, 1, r, g, b, a, sides);
    }

    public static void draw_cube_line(BlockPos blockPos, int r, int g, int b, int a, String sides) {
        draw_cube_line(INSTANCE.func_178180_c(), blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), 1, 1, 1, r, g, b, a, sides);
    }

    public static BufferBuilder get_buffer_build() {
        return INSTANCE.func_178180_c();
    }

    public static void draw_cube(final BufferBuilder buffer, float x, float y, float z, float w, float h, float d, int r, int g, int b, int a, String sides) {
        if (((boolean) Arrays.asList(sides.split("-")).contains("down")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x + w, y, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("up")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x + w, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("north")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x + w, y, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("south")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("south")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("south")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x + w, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }
    }

    public static void draw_cube_line(final BufferBuilder buffer, float x, float y, float z, float w, float h, float d, int r, int g, int b, int a, String sides) {
        if (((boolean) Arrays.asList(sides.split("-")).contains("downwest")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("upwest")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("downeast")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x + w, y, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("upeast")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x + w, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }

       if (((boolean) Arrays.asList(sides.split("-")).contains("downnorth")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y, z).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("upnorth")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("downsouth")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("upsouth")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("nortwest")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("norteast")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x + w, y, z).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y + h, z).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("southweast")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }

        if (((boolean) Arrays.asList(sides.split("-")).contains("southeast")) || sides.equalsIgnoreCase("all")) {
            buffer.func_181662_b(x + w, y, z + d).func_181669_b(r, g, b, a).func_181675_d();
            buffer.func_181662_b(x + w, y + h, z + d).func_181669_b(r, g, b, a).func_181675_d();
        }
    }
}